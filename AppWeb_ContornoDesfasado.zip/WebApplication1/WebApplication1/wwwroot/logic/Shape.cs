﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace WebApplication1
{
    class Shape
    {
        public List<Segment> OrderedSegments { get; set; }
        public List<Point> OrderedSegmentsPolygon { get; set; }
        public bool Clockwise { get; set; }

        public enum PointInsidePolygon
        {
            Inline,
            Outside,
            Inside,
            Undefined
        }

        public enum PolygonInsidePolygon
        {
            Outside,
            Inside,
            TangentInside,
            TangentOutside,
            Intersect,
            Undefined
        }

        public Shape()
        {            
            OrderedSegments = new List<Segment>();      //Lista de los segmentos del poligono
            OrderedSegmentsPolygon = new List<Point>(); //Lista de los puntos del poligono
        }
        
        public PointInsidePolygon InsidePolygon(Point p)
        {
            Point axis = new Point(-2f * GlobalVariables.ColOffset, p.Y); //Second point representing horizontal line
            Line hLine = new Line(axis, p);
            axis = new Point(p.X, -2f * GlobalVariables.ColOffset); //Second point representing vertical line
            Line vLine = new Line(axis, p);

            List<Intersection> hNum = RayCasting(hLine);
            PointInsidePolygon eHNum = PointInsidePolygon.Outside;
            if (hNum == null) eHNum = PointInsidePolygon.Undefined;
            else
            {                
                foreach (Intersection i in hNum)
                {
                    if (i.Equals(p)) eHNum = PointInsidePolygon.Inline;
                }
                if (eHNum == PointInsidePolygon.Outside && (hNum.Count % 2 != 0)) eHNum = PointInsidePolygon.Inside;
            }

            List<Intersection> vNum = RayCasting(vLine);
            PointInsidePolygon eVNum = PointInsidePolygon.Outside;

            if (vNum == null) eVNum = PointInsidePolygon.Undefined;
            else
            {
                foreach (Intersection i in vNum)
                {
                    if (i.Equals(p)) eVNum = PointInsidePolygon.Inline;
                }
                if (eVNum == PointInsidePolygon.Outside && (vNum.Count % 2 != 0)) eVNum = PointInsidePolygon.Inside;
            }

            if (eHNum == eVNum) return eHNum;
            if (eHNum == PointInsidePolygon.Undefined) return eVNum;
            if (eVNum == PointInsidePolygon.Undefined) return eHNum;
            if (eHNum == PointInsidePolygon.Inside && eVNum == PointInsidePolygon.Inline) return eVNum;
            if (eVNum == PointInsidePolygon.Inside && eHNum == PointInsidePolygon.Inline) return eHNum;
            if (eHNum == PointInsidePolygon.Outside && eVNum == PointInsidePolygon.Inline) return eVNum;
            if (eVNum == PointInsidePolygon.Outside && eHNum == PointInsidePolygon.Inline) return eHNum;
            if (eHNum == PointInsidePolygon.Outside && eVNum == PointInsidePolygon.Inside) return (vNum.Count > hNum.Count ? eVNum : eHNum);//throw new Exception("Inconsistent InsidePolygon result");
            if (eVNum == PointInsidePolygon.Outside && eHNum == PointInsidePolygon.Inside) return (vNum.Count > hNum.Count ? eVNum : eHNum);//throw new Exception("Inconsistent InsidePolygon result");
            throw new Exception("InsidePolygon result not covered");
        }

        public List<Intersection> RayCasting(Line line)
        {
            List<Intersection> intersec;
            List<Intersection> intersecInSegment = new List<Intersection>();

            for (int index = 0; index < OrderedSegments.Count; ++index)
            {
                var figure = OrderedSegments[index];
                intersec = figure.CalculateIntersection(line);

                for (int j = 0; j < intersec.Count; j++)
                    //Excluding Extreme
                    if (intersec[j].S_PointInsideSegment == Intersection.PointInsideSegment.Inside
                         &&
                         intersec[j].S2_PointInsideSegment == Intersection.PointInsideSegment.Inside
                         )
                    {
                        if (!float.IsInfinity(intersec[j].X) && !float.IsInfinity(intersec[j].Y))
                            intersecInSegment.Add(intersec[j]);
                    }
                    else if (intersec[j].S_PointInsideSegment == Intersection.PointInsideSegment.Extreme
                         ||
                         intersec[j].S2_PointInsideSegment == Intersection.PointInsideSegment.Extreme)
                    {
                        return null;
                    }
            }

            intersecInSegment = intersecInSegment.Distinct().ToList();

            return intersecInSegment; // (intersecInSegment.Count % 2 != 0);
        }

        public Point GetMinCoordinates()
        {
            Point p = new Point(float.MaxValue, float.MaxValue);

            foreach (Point q in OrderedSegmentsPolygon)
            {
                if (q.X < p.X) p.X = q.X;
                if (q.Y < p.Y) p.Y = q.Y;
            }
            return p;
        }

        public Point GetMaxCoordinates()
        {
            Point p = new Point(float.MinValue, float.MinValue);

            foreach (Point q in OrderedSegmentsPolygon)
            {
                if (q.X > p.X) p.X = q.X;
                if (q.Y > p.Y) p.Y = q.Y;
            }
            return p;
        }

        public Shape CalculateExternalContour(bool bCollisionMeta)
        {
            Segment aSegment;
            Shape aShape = new Shape();
            aShape.Clockwise = Clockwise;

            float offSet;
            if (bCollisionMeta) offSet = GlobalVariables.ColOffset;
            else offSet = GlobalVariables.CutOffset;

            foreach (Segment original in OrderedSegments)
            {
                if (original.Orientation.Length >= 1)
                { 
                    aSegment = original.Move(offSet);
                    if (aSegment != null)
                    {
                        //Inverted Beziers not allowed
                        //Segments too small not allowed (Segments will be connected later)
                        if (original.Orientation.dotProduct(aSegment.Orientation) < Math.PI / 2 && (aSegment.Orientation.Length >= 1f))
                        {
                            aSegment.StrokeWidth = "0.1";
                            if (bCollisionMeta)
                            { 
                                aSegment.Stroke = "#000000";
                                aShape.OrderedSegments.Add(aSegment);
                            }
                            else
                            { 
                                aSegment.Stroke = "#FF0000";
                                aShape.OrderedSegments.Add(aSegment);
                            }
                        }
                    }
                }
            }
            return aShape;
        }

        private QuadraticCurve AddQuad(Segment a, Segment b, Intersection intersection)
        {
            QuadraticCurve qCurve = new QuadraticCurve(a.EndPoint, intersection, b.StartPoint);
            qCurve.Shape = a.Shape;
            a.CopySVGAttributes(qCurve);
            qCurve.Stroke = "#000000";
            return qCurve;
        }

        private Line AddLine(Segment a, Segment b, bool bCollisionMeta)
        {
            Line line = new Line(a.EndPoint, b.StartPoint);
            line.Shape = a.Shape;
            a.CopySVGAttributes(line);

            if (bCollisionMeta) line.Stroke = "#000000";
            else line.Stroke = "#FF0000";

            return line;
        }

        private Intersection GetBestIntersection(List<Intersection> intersection, Point approximate)
        {
            float minimumDistance = float.MaxValue;
            float distance;
            Intersection p = null;
            for (int k = 0; k < intersection.Count; ++k)
            {
                //Comprobar que no sea valores raros
                if (float.IsNaN(intersection[k].X) || float.IsNaN(intersection[k].Y))
                    break;
                if (float.IsInfinity(intersection[k].X) || float.IsInfinity(intersection[k].Y))
                    break;

                //Mirar que interseccion esta mas cerca del punto inicial del Bezier
                distance = intersection[k].Distance(approximate);
                if (minimumDistance > distance)
                {
                    minimumDistance = distance;
                    p = intersection[k];
                }
            }
            return p;
        }

        public bool CheckShapeIntersect(Shape shape) //Convex hull logic
        {
            Point p1, p2, p3, p4;
            List<Intersection> intersect;
            List<Line> l = new List<Line>(), o = new List<Line>();

            float x_min = float.MaxValue;
            float x_max = float.MinValue;
            float y_min = float.MaxValue;
            float y_max = float.MinValue;

            foreach (Segment s in OrderedSegments)
            {
                if (x_min > s.StartPoint.X)
                    x_min = s.StartPoint.X;
                if (x_min > s.EndPoint.X)
                    x_min = s.EndPoint.X;

                if (y_min > s.StartPoint.Y)
                    y_min = s.StartPoint.Y;
                if (y_min > s.EndPoint.Y)
                    y_min = s.EndPoint.Y;

                if (x_max < s.StartPoint.X)
                    x_max = s.StartPoint.X;
                if (x_max < s.EndPoint.X)
                    x_max = s.EndPoint.X;

                if (y_max < s.StartPoint.Y)
                    y_max = s.StartPoint.Y;
                if (y_max < s.EndPoint.Y)
                    y_max = s.EndPoint.Y;
            }

            p1 = new Point(x_min, y_min);
            p2 = new Point(x_min, y_max);
            p3 = new Point(x_max, y_min);
            p4 = new Point(x_max, y_max);

            l.Add(new Line(p1, p2));
            l.Add(new Line(p2, p3));
            l.Add(new Line(p3, p4));
            l.Add(new Line(p4, p1));

            x_min = float.MaxValue;
            x_max = float.MinValue;
            y_min = float.MaxValue;
            y_max = float.MinValue;

            foreach (Segment s in OrderedSegments)
            {
                if (x_min > s.StartPoint.X)
                    x_min = s.StartPoint.X;
                if (x_min > s.EndPoint.X)
                    x_min = s.EndPoint.X;

                if (y_min > s.StartPoint.Y)
                    y_min = s.StartPoint.Y;
                if (y_min > s.EndPoint.Y)
                    y_min = s.EndPoint.Y;

                if (x_max < s.StartPoint.X)
                    x_max = s.StartPoint.X;
                if (x_max < s.EndPoint.X)
                    x_max = s.EndPoint.X;

                if (y_max < s.StartPoint.Y)
                    y_max = s.StartPoint.Y;
                if (y_max < s.EndPoint.Y)
                    y_max = s.EndPoint.Y;
            }

            p1 = new Point(x_min, y_min);
            p2 = new Point(x_min, y_max);
            p3 = new Point(x_max, y_min);
            p4 = new Point(x_max, y_max);

            o.Add(new Line(p1, p2));
            o.Add(new Line(p2, p3));
            o.Add(new Line(p3, p4));
            o.Add(new Line(p4, p1));

            for (int i = 0, j = 0; i < 4; ++i)
            {
                for (j = 0; j < 4; ++j)
                {
                    intersect = l[i].CalculateIntersection(o[j]);
                    if (intersect.Count > 0)
                        return true;
                }
            }

            return false;
        }

        public void FixContour(bool bCollisionMeta)
        {            
            Segment possibleSegmentToCreate;
            Segment previous, current, next;

            //Recorrer todas los segmentos por parejas.
            int numSegmentsRemoved = 0;
            
            do
            {
                if (OrderedSegments.Count == 1)
                {                 
                    OrderedSegments.Clear();
                    return;
                }
                foreach (Segment s in OrderedSegments.ToList())
                {
                    if (s.Original == null)
                    {
                        OrderedSegments.Remove(s);
                    }
                }
                
                for (int i = 0, j = 1, k=0; k < OrderedSegments.Count; ++i, ++j, ++k)
                {
                    if (i >= OrderedSegments.Count) i = 0;
                    if (j >= OrderedSegments.Count) j = 0;
                    
                    possibleSegmentToCreate = null;
                    previous = OrderedSegments[i];
                    next = OrderedSegments[j];
                    List<Intersection> intersections;
                    if (!previous.EndPoint.Equals(next.StartPoint))
                    {
                        intersections = previous.CalculateIntersection(next);
                        foreach(Intersection intersection in intersections.ToList())
                        {
                            if ((intersection.S_PointInsideSegment == Intersection.PointInsideSegment.Outside && intersection.S.GetType().Name == "BezierCurve")
                                || (intersection.S2_PointInsideSegment == Intersection.PointInsideSegment.Outside && intersection.S2.GetType().Name == "BezierCurve"))
                                intersections.Remove(intersection);
                        }
                        if (intersections.Count < 1)
                        {
                            possibleSegmentToCreate = AddLine(previous, next, bCollisionMeta);
                        }
                        else
                        {
                            Intersection p = GetBestIntersection(intersections, previous.EndPoint);

                            if (p == null)
                            {
                                possibleSegmentToCreate = AddLine(previous, next, bCollisionMeta);
                            }
                            else
                            {
                                if (p.ExactlyEquals(previous.StartPoint))
                                {
                                    OrderedSegments.Remove(previous);
                                    --k;
                                }
                                else
                                    previous.MoveEndPoint(p);


                                if (p.ExactlyEquals(next.EndPoint))
                                {
                                    OrderedSegments.Remove(next);
                                    --k;
                                }
                                else
                                    next.MoveStartPoint(p);
                            }
                        }
                    }                    


                    if (possibleSegmentToCreate != null)
                    {
                        OrderedSegments.Insert(j, possibleSegmentToCreate);
                        ++i; ++j; ++k;
                    }

                    if (OrderedSegments.Count() > 10000) throw new Exception("Big loop");
                }

                numSegmentsRemoved = 0;                
                for(int i= 0; i < OrderedSegments.Count; i++) // each(Segment s in segments.ToList<Segment>())
                {
                    if (i == 0) previous = OrderedSegments[OrderedSegments.Count-1];
                    else previous = OrderedSegments[i - 1];

                    current = OrderedSegments[i];

                    if (i >= OrderedSegments.Count-1) next = OrderedSegments[0];
                    else next = OrderedSegments[i + 1];

                    
                    if ((current.Original != null) &&
                        current.Orientation.dotProduct(current.Original.Orientation) > Math.PI/2
                        && current.GetType().Name == "Line") //Remove not fictitius lines that were reversed                        
                    {
                        numSegmentsRemoved++;
                        OrderedSegments.Remove(current);
                        --i;
                    }                                            
                }
            }
            while (numSegmentsRemoved > 0);
        }
        
        public void Reverse()
        {
            List<Segment> original = new List<Segment>();
            for (int i = OrderedSegments.Count - 1; i >= 0; --i)
            {
                OrderedSegments[i].Reverse();
                original.Add(OrderedSegments[i]);
            }

            List<Point> poly = new List<Point>();
            for (int i = OrderedSegmentsPolygon.Count - 1; i >= 0; --i)
                poly.Add(OrderedSegmentsPolygon[i]);

            OrderedSegments = original;
            OrderedSegmentsPolygon = poly;
            Clockwise = !Clockwise;
        }

        public Intersection SortByDistance(Point point, List<Intersection> list)
        {
            Intersection closest = null;
            float min, dist;
            
            min = float.MaxValue;
            foreach(Intersection q in list)
            {
                dist = point.Distance(q);
                if(dist < min)
                {
                    min = dist;
                    closest = q;
                }
            }

            return closest;
        }

        public List<Segment> RearrangeList(List<Segment> segments)
        {
            Point origin = new Point(-10, -10);
            float minDist = float.MaxValue, dist;
            int pos = 0;
            List<Segment> rearranged = new List<Segment>();

            //Get point closest to origin to set as first
            for(int i = 0; i < segments.Count; ++i)
            {
                dist = origin.Distance(segments[i].StartPoint);
                if (dist < minDist)
                {
                    minDist = dist;
                    pos = i;
                }
            }

            //Rearrange List with first element being the closest start point to the origin
            do
            {
                if (pos == segments.Count) pos = 0;
                rearranged.Add(segments[pos++]);
            } while (rearranged.Count < segments.Count);

            return rearranged;
        }

        public void ToPoly()
        {
            foreach (Segment s in OrderedSegments)
                OrderedSegmentsPolygon.Add(s.StartPoint);
        }

        public bool Union(Shape oShape)
        {
            Intersection inter;
            List<Intersection> intersections = new List<Intersection>();
            List<Point> remove = new List<Point>();
            List<Intersection> cut;

            //Que esten las dos figuras orientadas counterclockwise
            if (this.Clockwise)
                this.Reverse();
            if (oShape.Clockwise)
                oShape.Reverse();
            
            //Buscamos el primer punto del polinomio que sea mas cercano al origen
            float minL = float.MaxValue;
            Point origin = new Point(0f, 0f), closest = null;
            Vector vector;
            foreach (Point p in OrderedSegmentsPolygon)
            {
                vector = new Vector(origin, p);
                if (minL > vector.Length)
                {
                    minL = vector.Length;
                    closest = p;
                }
            }

            foreach (Point p in oShape.OrderedSegmentsPolygon)
            {
                vector = new Vector(origin, p);
                if (minL > vector.Length)
                {
                    minL = vector.Length;
                    closest = p;
                }
            }

            //Reorganizar la lista con el segmento que contenga el punto mas cercano al origen primero.
            bool polygon = true; //Polygono que tiene el punto mas cercano en uno de sus segmentos.
            int index = 0;
            List<Segment> union = new List<Segment>();
            Segment current_segment = null;
            foreach (Segment s in OrderedSegments.ToList())
            {
                if (s.StartPoint.Equals(closest))
                {
                    RearrangeList(index, OrderedSegments);
                    polygon = true;
                    current_segment = OrderedSegments[0];
                    break;
                }
                ++index;
            }

            index = 0;
            foreach (Segment s in oShape.OrderedSegments.ToList())
            {
                if (s.StartPoint.Equals(closest))
                {
                    RearrangeList(index, oShape.OrderedSegments);
                    polygon = false;
                    current_segment = oShape.OrderedSegments[0];
                    break;
                }
                ++index;
            }

            //Union Logic

            index = 0;
            Intersection prevInter = null;
            Segment prevSegment = null;
            List<Segment> c_poly, o_poly;
            Shape currentShape, otherShape;
            bool bGoOn = true;

            /* string test; */ //For Debuging
            Shape a = new Shape();
            a.OrderedSegments = union;

            do
            {
                if (polygon)
                {
                    c_poly = OrderedSegments;
                    o_poly = oShape.OrderedSegments;

                    currentShape = this;
                    otherShape = oShape;
                }
                else
                {
                    c_poly = oShape.OrderedSegments;
                    o_poly = OrderedSegments;

                    currentShape = oShape;
                    otherShape = this;
                }

                //Buscar intersecciones en el segmento.
                for (int i = 0; i < o_poly.Count; ++i)
                {
                    cut = current_segment.CalculateIntersection(o_poly[i]);
                    if (cut.Count > 0)
                        inter = cut[0]; //Possibility to apply some criteria to select the best point.
                    else inter = null;
                    if (inter != null &&
                             inter.S_PointInsideSegment != Intersection.PointInsideSegment.Outside &&
                             inter.S2_PointInsideSegment != Intersection.PointInsideSegment.Outside &&                    
                            !inter.Equals(prevInter)) //Extreme intersection in some segment
                    {
                       if (!o_poly[i].EndPoint.ExactlyEquals(inter)) //Exactly needed. Otherwise, we lose the shape swap.
                        {
                           
                            float toInside = current_segment.Orientation.crossProduct2D(o_poly[i].Orientation);
                            if (current_segment.EndPoint.ExactlyEquals(inter))
                            {
                                Segment nextSegment;
                                int j = c_poly.IndexOf(current_segment);
                                if (j == -1) j = c_poly.IndexOf(current_segment.Original);
                                if (j == c_poly.Count - 1) nextSegment = c_poly[0];
                                else nextSegment = c_poly[j + 1];

                                float relativeAngle = nextSegment.Orientation.crossProduct2D(o_poly[i].Orientation);
                                if (relativeAngle >= 0.01)
                                    intersections.Add(inter);
                                else if (relativeAngle >= -0.01) //Parallel vectors
                                {
                                    if (current_segment.Orientation.crossProduct2D(o_poly[i].Orientation) > current_segment.Orientation.crossProduct2D(nextSegment.Orientation))
                                        intersections.Add(inter);
                                }
                            }
                            else
                            {
                                if (toInside >= 0.01)
                                    intersections.Add(inter);
                            }
                        }
                    }                    
                }

                //Si intersecciona
                if (intersections.Count > 0)
                {
                    polygon = !polygon; //Cambiamos el polygono para el siguiente ciclo.
                    Segment[] segments = new Segment[2];

                    if (intersections.Count > 1)
                    {
                        Intersection close = null; //La interseccion mas cercana al StartPoint del primer segmento.

                        //Buscar cual es la interseccion mas cercana
                        minL = float.MaxValue;
                        foreach (Intersection i in intersections)
                        {
                            segments[0] = new Line(current_segment.StartPoint, i);
                            if (segments[0].Length < minL)
                            {
                                minL = segments[0].Length;
                                close = i;
                            }
                        }

                        segments = GetCutIntersectingSegments(close);
                        if (segments[0] != null && !segments[0].StartPoint.Equals(segments[0].EndPoint))
                            union.Add(segments[0]);

                        prevInter = close;
                        prevSegment = current_segment;
                        current_segment = segments[1];
                        intersections.Clear();
                    }
                    else
                    {
                        segments = GetCutIntersectingSegments(intersections[0]);
                        if (segments[0] != null && !segments[0].StartPoint.ExactlyEquals(segments[0].EndPoint))
                            union.Add(segments[0]);
                        
                        prevInter = intersections[0];
                        prevSegment = current_segment;                        
                        current_segment = segments[1];
                        
                        intersections.Clear();
                    }
                }
                //Si no intersecciona
                else
                {
                    if (!current_segment.StartPoint.Equals(current_segment.EndPoint))
                        union.Add(current_segment);
                    int j = c_poly.IndexOf(current_segment);
                    if (j == -1) j = c_poly.IndexOf(current_segment.Original);
                    if (j == c_poly.Count - 1) j = 0;
                    else j++;

                    prevSegment = current_segment;
                    current_segment = c_poly[j];
                    prevInter = null;
                }

                /*Debug purposes*/                                                
                //test = a.ToSVGPath();                
                /*Debug purposes*/

                ++index;
                if (index > 10000) throw new Exception("Shape.Union: Fusing shapes. Big loop");

                if (union.Count() < 2) bGoOn = true;
                else if (!union[0].StartPoint.Equals(union[union.Count - 1].EndPoint)) bGoOn = true;//Mientras el startpoint del primer segmento no sea igual al endpoint del ultimo segmento.
                else bGoOn = false;
            } while (bGoOn); 

            //Cambiar la lista de segmentos original por la nueva
            OrderedSegments = union;

            //Cambiar la lista de puntos original por la nueva
            this.ToPoly();

            return true;
        }

        public void RearrangeList<T>(int index, List<T> list)
        {
            List<T> nList = new List<T>();

            do
            {
                if (index == list.Count) index = 0;
                nList.Add(list[index++]);
            } while (list.Count > nList.Count);

            list.Clear();
            list.AddRange(nList);
        }

        public PolygonInsidePolygon PolyInPoly(Shape oShape)
        {
            PolygonInsidePolygon result = PolygonInsidePolygon.Undefined;
            bool bTangent = false;
            foreach (Segment s in oShape.OrderedSegments)
            {
                switch(InsidePolygon(s.StartPoint))
                {
                    case PointInsidePolygon.Inline:
                        bTangent = true;
                        break;
                    case PointInsidePolygon.Outside:
                        switch (result)
                        {
                            case PolygonInsidePolygon.Undefined:
                                if (bTangent)
                                    result = PolygonInsidePolygon.TangentOutside;
                                else
                                    result = PolygonInsidePolygon.Outside;
                                break;
                            case PolygonInsidePolygon.TangentOutside:
                            case PolygonInsidePolygon.Outside:
                                break;
                            case PolygonInsidePolygon.Inside:
                            case PolygonInsidePolygon.Intersect:
                            case PolygonInsidePolygon.TangentInside:
                                result = PolygonInsidePolygon.Intersect;
                                return result; //Interrupt calculation                                
                        }                        
                        break;                    
                    case PointInsidePolygon.Inside:
                        switch (result)
                        {
                            case PolygonInsidePolygon.Undefined:
                                if (bTangent)
                                    result = PolygonInsidePolygon.TangentInside;
                                else
                                    result = PolygonInsidePolygon.Inside;
                                break;
                            case PolygonInsidePolygon.TangentInside:
                            case PolygonInsidePolygon.Inside:
                                break;
                            case PolygonInsidePolygon.Outside:
                            case PolygonInsidePolygon.Intersect:
                            case PolygonInsidePolygon.TangentOutside:
                                result = PolygonInsidePolygon.Intersect;
                                return result; //Interrupt calculation                                
                        }
                        break;                        
                };

                List<Intersection> ray = RayCasting((Line) s);
                if (ray != null && ray.Count > 1) return PolygonInsidePolygon.Intersect;
            }
            return result;
        }

        public string ToSVGPath()
        {
            string sResult = "";
            foreach (Segment external in OrderedSegments)
            {
                sResult += external.ToSVGPath();
            }

            return sResult;
        }

        public Segment[] GetCutIntersectingSegments(Intersection intersection)
        {
            Segment[] segments = new Segment[2];

            switch (intersection.S.GetType().Name)
            {
                case "Line":
                    segments[0] = new Line((Line)intersection.S);                    
                    break;
                case "BezierCurve":
                    segments[0] = new BezierCurve((BezierCurve)intersection.S);
                    break;
                default:
                    throw new Exception("Segment Cut not computable.");
            }

            switch (intersection.S2.GetType().Name)
            {
                case "Line":
                    segments[1] = new Line((Line)intersection.S2);
                    break;
                case "BezierCurve":
                    segments[1] = new BezierCurve((BezierCurve)intersection.S2);
                    break;
                default:
                    throw new Exception("Segment Cut not computable.");
            }

            if (intersection.ExactlyEquals(segments[0].StartPoint))
            {
                segments[0] = null;
            }
            else                
            {
                segments[0].MoveEndPoint(intersection);
                segments[0].Original = intersection.S;
                intersection.S.CopySVGAttributes(segments[0]);
            }                                                           

            if (intersection.ExactlyEquals(segments[1].EndPoint))
            {
                segments[1] = null;
            }
            else
            {
                segments[1].MoveStartPoint(intersection);
                segments[1].Original = intersection.S2;
                intersection.S2.CopySVGAttributes(segments[1]);
            }
                                      

            return segments;
        }

        public List<Shape> SelfIntersect(bool originalCall)
        {
            int cut_index = 0;
            int end_index = 0;
            int s_between = 0;
            bool cut = false;

            Intersection intersection = null;
            Shape newShape = null;

            List<Shape> shapes = new List<Shape>();
            Shape other = new Shape();
            List<Intersection> intersections;

            //Check if segment intersects with others
            for (int i = 0, j = 0, count = 1; i < OrderedSegments.Count; ++i)
            {
                for (count = 1, j = i + 2; count < OrderedSegments.Count; ++count, ++j)
                {
                    if (j >= OrderedSegments.Count) j = 0;
                    if (i == j || i + 1 == j || i - 1 == j) continue;       //skip self, next & previous
                    if (i == 0 && j == OrderedSegments.Count - 1) continue; //skip previous
                    if (j == 0 && i == OrderedSegments.Count - 1) continue; //skip previous


                    //Compute if intersection exist and is valid
                    intersections = OrderedSegments[i].CalculateIntersection(OrderedSegments[j]);
                    if (intersections != null)
                        if (intersections.Count > 0
                        && (intersections[0].S_PointInsideSegment != Intersection.PointInsideSegment.Outside)
                        && (intersections[0].S2_PointInsideSegment != Intersection.PointInsideSegment.Outside))
                        {
                            intersection = intersections[0];
                            break;
                        }
                    intersections = null;
                }

                //If intersection is found
                if (intersection != null)
                {                                        
                    //Get loop start segment and end segment
                    cut_index = OrderedSegments.IndexOf(intersection.S);
                    end_index = OrderedSegments.IndexOf(intersection.S2);

                    //Get number of segments in new shape.
                    if (cut_index < end_index) s_between = ((end_index + 1) - (cut_index + 1)) + 1;
                    else s_between = OrderedSegments.Count + ((end_index + 1) - (cut_index + 1) + 1);

                    //add segments to shape & remove them from original shape
                    for (i = cut_index, count = 0; count < s_between; ++count)
                    {
                        if (i >= OrderedSegments.Count)
                            i = 0;

                        OrderedSegments[i].Shape = other;
                        other.OrderedSegments.Add(OrderedSegments[i]);
                        OrderedSegments.Remove(OrderedSegments[i]);
                    }

                    //Insert both cut shapes in original shape
                    Segment[] segments = GetCutIntersectingSegments(intersection);
                    if (segments[1] != null)
                        OrderedSegments.Insert(i, segments[1]);
                    if (segments[0] != null)
                        OrderedSegments.Insert(i, segments[0]);


                    //Rearange first and last segments to fit the intersection.
                    if (other.OrderedSegments.First().EndPoint.ExactlyEquals(intersection))
                        other.OrderedSegments.Remove(other.OrderedSegments.First());
                    else
                        other.OrderedSegments.First().MoveStartPoint(intersection);

                    if (other.OrderedSegments.Last().StartPoint.ExactlyEquals(intersection))
                        other.OrderedSegments.Remove(other.OrderedSegments.Last());
                    else
                        other.OrderedSegments.Last().MoveEndPoint(intersection);

                    //Asign correct shape to all segments
                    foreach (Segment s in other.OrderedSegments)
                        s.Shape = other;

                    other.IsClockwise();
                    shapes.AddRange(other.SelfIntersect(false));
                    cut = true;
                    break;
                }

                intersection = null;
                intersections = null;

                if (cut)
                    break;
            }


            newShape = new Shape();            
            newShape.OrderedSegments.AddRange(OrderedSegments);

            //Asign correct shape to all segments
            foreach (Segment s in newShape.OrderedSegments)
                s.Shape = newShape;

            newShape.IsClockwise();

            if (shapes.Count == 0 && !originalCall)
                shapes.Add(newShape);
            else            
                shapes.AddRange(newShape.SelfIntersect(false));                                
            
            return shapes;
        }

        public bool IsClockwise()
        {
            float bigest = float.MinValue;
            Segment segment = null;

            foreach(Segment s in this.OrderedSegments)
                if(s.Length > bigest)
                {
                    bigest = s.Length;
                    segment = s;
                }

            //If Segment is a Bezier Curve
            if (segment.GetType().Name == "BezierCurve")
            {
                BezierCurve curve = (BezierCurve)segment;
                List<Line> lines = curve.ToLines();
                int i_middle = (int)Math.Floor((float)lines.Count / 2f);
                segment = lines[i_middle]; //Middle Line
            }

            //Perpendicular point to check
            Point p = segment.StartPoint.Move(segment.Orientation.Unit(), (segment.Length / 2f));
            p = p.Move((new Vector(segment.StartPoint, segment.EndPoint).Unit().Rotate((float)-Math.PI / 2)), 4);

            if (this.InsidePolygon(p) == Shape.PointInsidePolygon.Outside)
                this.Clockwise = true;
            else
                this.Clockwise = false;

            return this.Clockwise;
        }
    }
}