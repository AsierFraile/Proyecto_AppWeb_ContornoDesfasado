﻿using System;
using System.Collections.Generic;
using System.Xml.Linq;

namespace WebApplication1
{
    class BezierCurve : Segment
    {
        //https://css-tricks.com/svg-path-syntax-illustrated-guide/

        public Point BezierStartPoint { get; set; }
        public Point BezierEndPoint { get; set; }
        public bool RelativeCoords { get; set; }

        public BezierCurve(Point startPoint, Point bezierStartPoint, Point bezierEndPoint, Point endPoint, bool relativeCoords)
        {
            StartPoint = startPoint;
            EndPoint = endPoint;
            BezierStartPoint = bezierStartPoint;
            BezierEndPoint = bezierEndPoint;            

            if (relativeCoords)
            {
                BezierEndPoint = BezierEndPoint.Move(new Vector(StartPoint.X, StartPoint.Y), 1);
                EndPoint = EndPoint.Move(new Vector(StartPoint.X, StartPoint.Y), 1);

                if (BezierStartPoint == null) //Smooth curve
                    BezierStartPoint = StartPoint;
                else
                    BezierStartPoint = BezierStartPoint.Move(new Vector(StartPoint.X, StartPoint.Y), 1);
                RelativeCoords = false;
            }
            else
            {
                BezierEndPoint = BezierEndPoint;
                EndPoint = EndPoint;
                if (BezierStartPoint == null) //Smooth curve
                    BezierStartPoint = StartPoint;
                else
                    BezierStartPoint = BezierStartPoint;
                RelativeCoords = false;
            }

            Orientation = new Vector(StartPoint, EndPoint);
        }

        public BezierCurve(BezierCurve oCurve)
        {
            StartPoint = new Point(oCurve.StartPoint);
            EndPoint = new Point(oCurve.EndPoint);
            BezierStartPoint = new Point(oCurve.BezierStartPoint);
            BezierEndPoint = new Point(oCurve.BezierEndPoint);
            Orientation = new Vector(StartPoint, EndPoint);
            RelativeCoords = false;
            Shape = oCurve.Shape;
        }

        public override Segment Move(float distance)
        {
            Vector vStart;
            Vector vEnd;

            if (StartPoint.ExactlyEquals(BezierStartPoint)) //Smooth curve
            {
                vStart = new Vector(StartPoint, BezierEndPoint);
                vEnd = new Vector(EndPoint, BezierEndPoint);
            }
            else
            {
                vStart = new Vector(StartPoint, BezierStartPoint);
                if (EndPoint.ExactlyEquals(BezierEndPoint)) //Smooth curve
                {
                    vEnd = new Vector(EndPoint, BezierStartPoint);
                }
                else
                {
                    vEnd = new Vector(EndPoint, BezierEndPoint);
                }
            }

            Vector vStartEnd = new Vector(StartPoint, EndPoint);
            Vector vEndStart = new Vector(EndPoint, StartPoint);

            Vector vStartRotated = vStart.Rotate((float)((!Shape.Clockwise ? 1 : -1) * Math.PI / 2)).Unit();
            Point newStartPoint = StartPoint.Move(vStartRotated, distance);

            Vector vEndRotated = vEnd.Rotate((float)(float)((!Shape.Clockwise ? -1 : 1) * Math.PI / 2)).Unit();
            Point newEndPoint = EndPoint.Move(vEndRotated, distance);

            Point newBezierStartPoint;
            Point newBezierEndPoint;
            Line beziersLine;
            Line lineStart;
            Line lineEnd;
            Segment newBeziersLine;

            if (StartPoint.Equals(BezierStartPoint) || (EndPoint.Equals(BezierEndPoint)))//Smooth curve
            {
                Vector v = vStart + vEnd;
                lineStart = new Line(newStartPoint, vStart);
                lineEnd = new Line(newEndPoint, vEnd);

                newBezierStartPoint = newStartPoint;
                newBezierEndPoint = lineStart.CalculateIntersection(lineEnd)[0];
            }
            else
            {
                beziersLine = new Line(BezierStartPoint, BezierEndPoint);
                newBeziersLine = beziersLine.Move(vStartRotated, distance);

                lineStart = new Line(newStartPoint, vStart);
                lineEnd = new Line(newEndPoint, vEnd);
                newBezierStartPoint = newBeziersLine.CalculateIntersection(lineStart)[0];
                newBezierEndPoint = newBeziersLine.CalculateIntersection(lineEnd)[0];
            }

            //Check enormous bezier points due to small sectors with almost parallel vectors.
            Vector vStartBezier = new Vector(newStartPoint, newBezierStartPoint);
            Vector vEndBezier = new Vector(newEndPoint, newBezierEndPoint);
            if (vStartBezier.Length > vStart.Length + (distance * 4) ||
                vEndBezier.Length > vEnd.Length + (distance * 4))
            {
                newBezierStartPoint = newStartPoint.Move(vStart, 1);
                newBezierEndPoint = newEndPoint.Move(vEnd, 1);
            }

            Segment result = new BezierCurve(newStartPoint,
                                                newBezierStartPoint,
                                                newBezierEndPoint,
                                                newEndPoint,
                                                false);

            
            Vector v1 = new Vector(newStartPoint, newBezierStartPoint);
            Vector v2 = new Vector(newBezierEndPoint, newEndPoint);
            Vector v3 = new Vector(newStartPoint, newEndPoint);
            //if (v1.dotProduct(v2) < 0.18f && v1.dotProduct(v3) < 0.18f && v2.dotProduct(v3) < 0.18f)
            //{//This is not a bezier curve but a line.
            //    result = new Line(newStartPoint, newEndPoint);
            //}

            CopySVGAttributes(result);
            result.Original = this;            
            result.Stroke = "#000000";

            return result;
        }
        public override string ToSVGPath()
        {
            if (StartPoint.Equals(BezierStartPoint))
                return "M" +
                        Math.Round(StartPoint.X, 3) + "," + Math.Round(StartPoint.Y, 3) +
                   (RelativeCoords ? "s" : "S") +
                        Math.Round(BezierEndPoint.X, 3) + "," + Math.Round(BezierEndPoint.Y, 3) + "," +
                        Math.Round(EndPoint.X, 3) + "," + Math.Round(EndPoint.Y, 3);
            else if (EndPoint.Equals(BezierEndPoint))
                return "M" +
                        Math.Round(StartPoint.X, 3) + "," + Math.Round(StartPoint.Y, 3) +
                   (RelativeCoords ? "s" : "S") +
                        Math.Round(BezierStartPoint.X, 3) + "," + Math.Round(BezierStartPoint.Y, 3) + "," +
                        Math.Round(EndPoint.X, 3) + "," + Math.Round(EndPoint.Y, 3);
            else
                return "M" +
                        Math.Round(StartPoint.X, 3) + "," + Math.Round(StartPoint.Y, 3) +
                   (RelativeCoords ? "c" : "C") +
                        Math.Round(BezierStartPoint.X, 3) + "," + Math.Round(BezierStartPoint.Y, 3) + "," +
                        Math.Round(BezierEndPoint.X, 3) + "," + Math.Round(BezierEndPoint.Y, 3) + "," +
                        Math.Round(EndPoint.X, 3) + "," + Math.Round(EndPoint.Y, 3);
        }
        public override XElement ToSVG(XNamespace ns)
        {
            return new XElement(ns + "path",
                new XAttribute("fill", Fill),
                new XAttribute("stroke", Stroke),
                new XAttribute("stroke-width", StrokeWidth),
                new XAttribute("stroke-linecap", StrokeLineCap),
                new XAttribute("stroke-linejoin", StrokeLineJoin),
                new XAttribute("stroke-miterlimit", StrokeMiterLimit),
                new XAttribute("d", ToSVGPath())
               );
        }

        public List<Intersection> CalculateIntersectionBezierLine(Line segment)
        {
            //https://www.particleincell.com/2013/cubic-line-intersection/

            List<Intersection> resultList = new List<Intersection>();
            Intersection[] result = new Intersection[3];            

            //r(t)=(1−t)^3*P0 + 3*(1−t)^2*t*P1+3*(1−t)*t^2*P2 + t^3*P3,t∈[0,1]
            Point P0 = StartPoint;
            Point P1 = BezierStartPoint;
            Point P2 = BezierEndPoint;
            Point P3 = EndPoint;

            Point lineStart = segment.StartPoint.Move(new Vector(segment.EndPoint, segment.StartPoint), 1000);
            Point lineEnd = segment.EndPoint.Move(new Vector(segment.StartPoint, segment.EndPoint), 1000);

            float A = lineEnd.Y - lineStart.Y;                       // A=y2-y1
            float B = lineStart.X - lineEnd.X;                       //B=x1-x2
            float C = lineStart.X * (lineStart.Y - lineEnd.Y) +
                       lineStart.Y * (lineEnd.X - lineStart.X);     //C=x1*(y1-y2)+y1*(x2-x1)

            float[] bx = BezierCoeffs(P0.X, P1.X, P2.X, P3.X);
            float[] by = BezierCoeffs(P0.Y, P1.Y, P2.Y, P3.Y);

            //A* x(t) +B * y(t) + C = 0
            float[] P = {
                            A * bx[0] + B * by[0],        //t^3
                            A * bx[1] + B * by[1],        //t^2
                            A * bx[2] + B * by[2],        //t^1
                            A * bx[3] + B * by[3] + C,    //1
                         };

            float[] r = CubicRoots(P);

            for (int i = 0; i < 3; i++)
            {
                float t = r[i];
                result[i] = new Intersection(new Point(bx[0] * t * t * t + bx[1] * t * t + bx[2] * t + bx[3],
                                                        by[0] * t * t * t + by[1] * t * t + by[2] * t + by[3]),
                                             t, -1, this, segment);
               
                /*above is intersection point assuming infinitely long line segment,
                  make sure we are also in bounds of the line*/
                float s;
                if ((lineEnd.X - lineStart.X) != 0)           /*if not vertical line*/
                    s = (result[i].X - lineStart.X) / (lineEnd.X - lineStart.X);
                else
                {
                    s = (result[i].Y - lineStart.Y) / (lineEnd.Y - lineStart.Y);
                }

                /*in bounds?*/
                if (!(t < 0 || t > 1.0 || s < 0 || s > 1.0))
                {
                    resultList.Add(result[i]);
                }
                else
                {
                    result[i].X = float.PositiveInfinity;
                    result[i].Y = float.PositiveInfinity;
                }
            }

            if (resultList.Count == 0)
            {//double check. Failing with too flat beziers.
                Line aLine = new Line(StartPoint, EndPoint);
                resultList = aLine.CalculateIntersectionLineLine((Line)segment);
                if (resultList.Count > 0)
                {
                    if ((resultList[0].S_PointInsideSegment == Intersection.PointInsideSegment.Extreme || resultList[0].S_PointInsideSegment == Intersection.PointInsideSegment.Inside)
                        &&
                        (resultList[0].S2_PointInsideSegment == Intersection.PointInsideSegment.Extreme || resultList[0].S2_PointInsideSegment == Intersection.PointInsideSegment.Inside))
                    {
                        if (aLine.EndPoint.X != aLine.StartPoint.X)
                            resultList[0].T = (resultList[0].X - aLine.StartPoint.X) / (aLine.EndPoint.X - aLine.StartPoint.X);
                        else
                            resultList[0].T = (resultList[0].Y - aLine.StartPoint.Y) / (aLine.EndPoint.Y - aLine.StartPoint.Y);
                    }
                    else
                        resultList.Clear();
                }
            }
            return resultList;
        }
        
        public List<Intersection> CalculateIntersectionBezierBezierRecursive(BezierCurve otherBezier, float size, float t, float t1, float t2)
        {
            List<Intersection> resultList = new List<Intersection>();
            if (size < 0.009f || float.IsNaN(size))
            {
                Point p = GetPointByT(t1);
                Point q = otherBezier.GetPointByT(t2);
                if (p.Equals(q))
                    resultList.Add(new Intersection(p, t1, t2, this, otherBezier));

                return resultList;
            }

            float maxX, minX, maxY, minY;
            BezierCurve[] bSplit, oSplit;
            bSplit = CasteljaoSplit(0.5f);
            oSplit = otherBezier.CasteljaoSplit(0.5f);
            t /= 2f;

            if (bSplit[0].ConvexHullIntersect(oSplit[0]))
            {                
                maxX = Math.Max(Math.Max(bSplit[0].StartPoint.X, bSplit[0].EndPoint.X), Math.Max(bSplit[0].BezierStartPoint.X, bSplit[0].BezierEndPoint.X));
                minX = Math.Min(Math.Min(bSplit[0].StartPoint.X, bSplit[0].EndPoint.X), Math.Min(bSplit[0].BezierStartPoint.X, bSplit[0].BezierEndPoint.X));
                maxY = Math.Max(Math.Max(bSplit[0].StartPoint.Y, bSplit[0].EndPoint.Y), Math.Max(bSplit[0].BezierStartPoint.Y, bSplit[0].BezierEndPoint.Y));
                minY = Math.Min(Math.Min(bSplit[0].StartPoint.Y, bSplit[0].EndPoint.Y), Math.Min(bSplit[0].BezierStartPoint.Y, bSplit[0].BezierEndPoint.Y));
                size = Math.Max(maxX - minX, maxY - minY);

                List<Intersection> recursiveResult = bSplit[0].CalculateIntersectionBezierBezierRecursive(oSplit[0], size, t, t1 - t/2, t2 - t/2);
                resultList.AddRange(recursiveResult);
            }

            if (bSplit[0].ConvexHullIntersect(oSplit[1]))
            {
                maxX = Math.Max(Math.Max(bSplit[0].StartPoint.X, bSplit[0].EndPoint.X), Math.Max(bSplit[0].BezierStartPoint.X, bSplit[0].BezierEndPoint.X));
                minX = Math.Min(Math.Min(bSplit[0].StartPoint.X, bSplit[0].EndPoint.X), Math.Min(bSplit[0].BezierStartPoint.X, bSplit[0].BezierEndPoint.X));
                maxY = Math.Max(Math.Max(bSplit[0].StartPoint.Y, bSplit[0].EndPoint.Y), Math.Max(bSplit[0].BezierStartPoint.Y, bSplit[0].BezierEndPoint.Y));
                minY = Math.Min(Math.Min(bSplit[0].StartPoint.Y, bSplit[0].EndPoint.Y), Math.Min(bSplit[0].BezierStartPoint.Y, bSplit[0].BezierEndPoint.Y));
                size = Math.Max(maxX - minX, maxY - minY);

                List<Intersection> recursiveResult = bSplit[0].CalculateIntersectionBezierBezierRecursive(oSplit[1], size, t, t1 - t / 2, t2 + t / 2);
                resultList.AddRange(recursiveResult);
            }
            if (bSplit[1].ConvexHullIntersect(oSplit[0]))
            {
                maxX = Math.Max(Math.Max(bSplit[1].StartPoint.X, bSplit[1].EndPoint.X), Math.Max(bSplit[1].BezierStartPoint.X, bSplit[1].BezierEndPoint.X));
                minX = Math.Min(Math.Min(bSplit[1].StartPoint.X, bSplit[1].EndPoint.X), Math.Min(bSplit[1].BezierStartPoint.X, bSplit[1].BezierEndPoint.X));
                maxY = Math.Max(Math.Max(bSplit[1].StartPoint.Y, bSplit[1].EndPoint.Y), Math.Max(bSplit[1].BezierStartPoint.Y, bSplit[1].BezierEndPoint.Y));
                minY = Math.Min(Math.Min(bSplit[1].StartPoint.Y, bSplit[1].EndPoint.Y), Math.Min(bSplit[1].BezierStartPoint.Y, bSplit[1].BezierEndPoint.Y));
                size = Math.Max(maxX - minX, maxY - minY);

                List<Intersection> recursiveResult = bSplit[1].CalculateIntersectionBezierBezierRecursive(oSplit[0], size, t, t1 + t / 2, t2 - t / 2);
                resultList.AddRange(recursiveResult);               
            }

            if (bSplit[1].ConvexHullIntersect(oSplit[1]))
            {
                maxX = Math.Max(Math.Max(bSplit[1].StartPoint.X, bSplit[1].EndPoint.X), Math.Max(bSplit[1].BezierStartPoint.X, bSplit[1].BezierEndPoint.X));
                minX = Math.Min(Math.Min(bSplit[1].StartPoint.X, bSplit[1].EndPoint.X), Math.Min(bSplit[1].BezierStartPoint.X, bSplit[1].BezierEndPoint.X));
                maxY = Math.Max(Math.Max(bSplit[1].StartPoint.Y, bSplit[1].EndPoint.Y), Math.Max(bSplit[1].BezierStartPoint.Y, bSplit[1].BezierEndPoint.Y));
                minY = Math.Min(Math.Min(bSplit[1].StartPoint.Y, bSplit[1].EndPoint.Y), Math.Min(bSplit[1].BezierStartPoint.Y, bSplit[1].BezierEndPoint.Y));
                size = Math.Max(maxX - minX, maxY - minY);

                List<Intersection> recursiveResult = bSplit[1].CalculateIntersectionBezierBezierRecursive(oSplit[1], size, t, t1 + t / 2, t2 + t / 2);
                resultList.AddRange(recursiveResult);
            }
            return resultList;
        }

        public List<Intersection> CalculateIntersectionBezierBezier(BezierCurve otherBezier)
        {            
            List<Intersection> resultList = CalculateIntersectionBezierBezierRecursive(otherBezier, float.MaxValue, 1f, 0.5f, 0.5f);
            foreach(Intersection i in resultList)
            {
                i.S = this;
                i.S_PointInsideSegment = InSegment(i);
                i.S2 = otherBezier;
                i.S2_PointInsideSegment = i.S2.InSegment(i);
            }
            return resultList;
        }

        public Line[] ConvexEnvelope()
        {
            Line[] p = new Line[4];
            p[0] = new Line(this.StartPoint, this.BezierStartPoint);
            p[1] = new Line(this.BezierStartPoint, this.BezierEndPoint);
            p[2] = new Line(this.BezierEndPoint, this.EndPoint);
            p[3] = new Line(this.EndPoint, this.StartPoint);
            return p;
        }

        public bool ConvexHullIntersect(BezierCurve bezier)
        {
            Line[] p = ConvexEnvelope();
            Line[] q = bezier.ConvexEnvelope();

            List<Intersection> intersection = null;

            for (int i = 0; i < 4; ++i)
            {
                for (int j = 0; j < 4; ++j)
                {
                    intersection = p[i].CalculateIntersection(q[j]);
                    if (intersection.Count > 0)
                        if ((intersection[0].S_PointInsideSegment == Intersection.PointInsideSegment.Extreme || intersection[0].S_PointInsideSegment == Intersection.PointInsideSegment.Inside) &&
                            (intersection[0].S2_PointInsideSegment == Intersection.PointInsideSegment.Extreme || intersection[0].S2_PointInsideSegment == Intersection.PointInsideSegment.Inside))
                            return true;
                }
            }
            return false;
        }

        private BezierCurve[] CasteljaoSplit(float t)
        {
            List<Vector> vectors = new List<Vector>();
            vectors.Add(new Vector(StartPoint, BezierStartPoint));
            vectors.Add(new Vector(BezierStartPoint, BezierEndPoint));
            vectors.Add(new Vector(BezierEndPoint, EndPoint));

            BezierCurve[] curve = new BezierCurve[2];
            curve[0] = new BezierCurve(StartPoint, BezierStartPoint, BezierEndPoint, EndPoint, RelativeCoords);
            curve[1] = new BezierCurve(StartPoint, BezierStartPoint, BezierEndPoint, EndPoint, RelativeCoords);
            curve[0].Shape = curve[1].Shape = this.Shape;

            Point tPoint = this.GetPointByT(t);
            curve[0].EndPoint = tPoint;
            curve[1].StartPoint = tPoint;

            //Left Curve
            Point control;
            if (StartPoint.ExactlyEquals(BezierStartPoint))
                control = StartPoint;
            else
                control = StartPoint.Move(vectors[0].Unit(), vectors[0].Length * t);
            if (!BezierStartPoint.ExactlyEquals(BezierEndPoint)) 
                curve[0].BezierStartPoint = curve[0].BezierStartPoint.Move(vectors[1].Unit(), vectors[1].Length * t);
            Vector vInter = new Vector(control, curve[0].BezierStartPoint);
            if (control.ExactlyEquals(curve[0].BezierStartPoint))
                curve[0].BezierEndPoint = control;
            else
                curve[0].BezierEndPoint = control.Move(vInter.Unit(), vInter.Length * t);
            curve[0].BezierStartPoint = control;

            //Rigth Curve
            if (!BezierEndPoint.ExactlyEquals(EndPoint))
                curve[1].BezierEndPoint = curve[1].BezierEndPoint.Move(vectors[2].Unit(), vectors[2].Length * t);
            if (!BezierStartPoint.ExactlyEquals(BezierEndPoint))
                curve[1].BezierStartPoint = curve[1].BezierStartPoint.Move(vectors[1].Unit(), vectors[1].Length * t);
            vInter = new Vector(curve[1].BezierStartPoint, curve[1].BezierEndPoint);
            if (!curve[1].BezierStartPoint.ExactlyEquals(curve[1].BezierEndPoint))
                curve[1].BezierStartPoint = curve[1].BezierStartPoint.Move(vInter.Unit(), vInter.Length * t);

            CopySVGAttributes(curve[0]);
            CopySVGAttributes(curve[1]);
            return curve;
        }

        public Point GetPointByT(float t)
        {
            float[] bx = BezierCoeffs(StartPoint.X, BezierStartPoint.X, BezierEndPoint.X, EndPoint.X);
            float[] by = BezierCoeffs(StartPoint.Y, BezierStartPoint.Y, BezierEndPoint.Y, EndPoint.Y);

            return new Point(bx[0] * t * t * t + bx[1] * t * t + bx[2] * t + bx[3],
                             by[0] * t * t * t + by[1] * t * t + by[2] * t + by[3]);
        }

        private float[] BezierCoeffs(float P0, float P1, float P2, float P3)
        {
            float[] Z = new float[4];
            Z[0] = -P0 + 3 * P1 + -3 * P2 + P3;
            Z[1] = 3 * P0 - 6 * P1 + 3 * P2;
            Z[2] = -3 * P0 + 3 * P1;
            Z[3] = P0;
            return Z;
        }

        private float[] CubicRoots(float[] P)
        {
            float[] t = new float[3];

            //Possible fix found at comments when a ==0
            if (P[0] == 0)
            {
                if (P[1] == 0)
                {
                    t[0] = -1 * (P[3] / P[2]);
                    t[1] = -1;
                    t[2] = -1;

                    /*discard out of spec roots*/
                    for (var i = 0; i < 1; i++)
                        if (t[i] < 0 || t[i] > 1.0) t[i] = -1;


                    /*sort but place -1 at the end*/
                    Array.Sort(t); //sortSpecial(t);

                    return t;
                }

                float DQ = (float)Math.Pow(P[2], 2) - 4 * P[1] * P[3]; // quadratic discriminant
                if (DQ >= 0)
                {
                    DQ = (float)Math.Sqrt(DQ);
                    t[0] = -1 * ((DQ + P[2]) / (2 * P[1]));
                    t[1] = ((DQ - P[2]) / (2 * P[1]));
                    t[2] = -1;

                    /*discard out of spec roots*/
                    for (var i = 0; i < 2; i++)
                        if (t[i] < 0 || t[i] > 1.0) t[i] = -1;

                    /*sort but place -1 at the end*/
                    Array.Sort(t); //sortSpecial(t);

                    return t;
                }
            }
            var a = P[0];
            var b = P[1];
            var c = P[2];
            var d = P[3];

            var A = b / a;
            var B = c / a;
            var C = d / a;

            var Q = (3 * B - Math.Pow(A, 2)) / 9;
            var R = (9 * A * B - 27 * C - 2 * Math.Pow(A, 3)) / 54;
            var D = Math.Pow(Q, 3) + Math.Pow(R, 2);    // polynomial discriminant


            float Im;

            if (D >= 0)                                 // complex or duplicate roots
            {
                float S = (float)(Math.Sign(R + Math.Sqrt(D)) * Math.Pow(Math.Abs(R + Math.Sqrt(D)), (1 / 3)));
                float T = (float)(Math.Sign(R - Math.Sqrt(D)) * Math.Pow(Math.Abs(R - Math.Sqrt(D)), (1 / 3)));

                t[0] = -A / 3 + (S + T);                    // real root
                t[1] = -A / 3 - (S + T) / 2;                  // real part of complex root
                t[2] = -A / 3 - (S + T) / 2;                  // real part of complex root
                Im = (float)Math.Abs(Math.Sqrt(3) * (S - T) / 2);    // complex part of root pair   

                /*discard complex roots*/
                if (Im != 0)
                {
                    t[1] = -1;
                    t[2] = -1;
                }

            }
            else                                          // distinct real roots
            {
                var th = Math.Acos(R / Math.Sqrt(-Math.Pow(Q, 3)));

                t[0] = (float)(2 * Math.Sqrt(-Q) * Math.Cos(th / 3) - A / 3);
                t[1] = (float)(2 * Math.Sqrt(-Q) * Math.Cos((th + 2 * Math.PI) / 3) - A / 3);
                t[2] = (float)(2 * Math.Sqrt(-Q) * Math.Cos((th + 4 * Math.PI) / 3) - A / 3);
                Im = 0.0f;
            }

            /*discard out of spec roots*/
            for (var i = 0; i < 3; i++)
                if (t[i] < 0 || t[i] > 1.0) t[i] = -1;

            /*sort but place -1 at the end*/
            Array.Sort(t); //sortSpecial(t);

            //console.log(t[0] + " " + t[1] + " " + t[2]);
            return t;
        }

        public override Intersection.PointInsideSegment InSegment(Point p)
        {
            return Intersection.PointInsideSegment.Inside;
        }

        public override Point GetMaxCoordinates()
        {
            Point p = new Point();
            p.X = float.MinValue;
            p.Y = float.MinValue;
        
            if (StartPoint.X > p.X) p.X = StartPoint.X;
            if (StartPoint.Y > p.Y) p.Y = StartPoint.Y;
        
            if (EndPoint.X > p.X) p.X = EndPoint.X;
            if (EndPoint.Y > p.Y) p.Y = EndPoint.Y;
        
            if (BezierStartPoint.X > p.X) p.X = BezierStartPoint.X;
            if (BezierStartPoint.Y > p.Y) p.Y = BezierStartPoint.Y;
        
            if (BezierEndPoint.X > p.X) p.X = BezierEndPoint.X;
            if (BezierEndPoint.Y > p.Y) p.Y = BezierEndPoint.Y;
        
            return p;
        }

        public override Point GetMinCoordinates()
        {
            Point p = new Point();
            p.X = float.MaxValue;
            p.Y = float.MaxValue;

            if (StartPoint.X < p.X) p.X = StartPoint.X;
            if (StartPoint.Y < p.Y) p.Y = StartPoint.Y;

            if (EndPoint.X < p.X) p.X = EndPoint.X;
            if (EndPoint.Y < p.Y) p.Y = EndPoint.Y;

            if (BezierStartPoint.X < p.X) p.X = BezierStartPoint.X;
            if (BezierStartPoint.Y < p.Y) p.Y = BezierStartPoint.Y;

            if (BezierEndPoint.X < p.X) p.X = BezierEndPoint.X;
            if (BezierEndPoint.Y < p.Y) p.Y = BezierEndPoint.Y;

            return p;
        }

        public override void Reverse()
        {
            Point swap = EndPoint;
            EndPoint = StartPoint;
            StartPoint = swap;

            swap = BezierEndPoint;
            BezierEndPoint = BezierStartPoint;
            BezierStartPoint = swap;

            Orientation = Orientation.Reverse();
        }

        public override bool MoveStartPoint(Intersection p)
        {
            float T;
            if (!StartPoint.Equals(p))
            {
                if (this.Equals(p.S)) T = p.T;
                else if (this.Equals(p.S2)) T = p.T2;
                else throw new Exception("Modifying Bezier with not related intersection");

                BezierCurve right = this.CasteljaoSplit(T)[1];

                StartPoint = right.StartPoint;
                BezierStartPoint = right.BezierStartPoint;
                BezierEndPoint = right.BezierEndPoint;
                EndPoint = right.EndPoint;

                Orientation = new Vector(StartPoint, EndPoint);
            }
            return true;
        }

        public override bool MoveEndPoint(Intersection p)
        {
            float T;
            if (!EndPoint.Equals(p))
            {
                if (this.Equals(p.S)) T = p.T;
                else if (this.Equals(p.S2)) T = p.T2;
                else throw new Exception("Modifying Bezier with not related intersection");

                BezierCurve left = this.CasteljaoSplit(T)[0];

                StartPoint = left.StartPoint;
                BezierStartPoint = left.BezierStartPoint;
                BezierEndPoint = left.BezierEndPoint;
                EndPoint = left.EndPoint;

                Orientation = new Vector(StartPoint, EndPoint);
            }
            return true;
        }

        public List<Line> ToLines()
        {
            bool done = false;
            float lineNum = 3f;
            float t1, t2, tIncrement;
            List<Line> lines = new List<Line>();

            do
            {
                lines.Clear();
                tIncrement = 1f / lineNum;
                t1 = 0f;
                t2 = t1 + tIncrement;
                for (int i = 0; i < lineNum; ++i)
                {
                    lines.Add(new Line(this.GetPointByT(t1), this.GetPointByT(t2)));
                    CopySVGAttributes(lines[i]);

                    t1 += tIncrement;
                    t2 += tIncrement;
                }

                if ((lines[0].Length * lineNum) < 2f)
                {
                    lines.Add(new Line(this.StartPoint, this.EndPoint));
                    return lines;
                }
                else if (lines[0].Length > 10f)
                    lineNum = lineNum + 2f;
                else
                    done = true;

            } while (!done);

            return lines;
        }

        public override bool Equals(Object obj)
        {
            if (obj.GetType().Name != "BezierCurve")
                return false;

            BezierCurve bezi = (BezierCurve)obj;
            if ((this.StartPoint.ExactlyEquals(bezi.StartPoint))
                && (this.EndPoint.ExactlyEquals(bezi.EndPoint))
                && (this.BezierEndPoint.ExactlyEquals(bezi.BezierEndPoint))
                && (this.BezierStartPoint.ExactlyEquals(bezi.BezierStartPoint))
                && (this.RelativeCoords == bezi.RelativeCoords))
                return true;
            else
                return false;
        }
    }
}
