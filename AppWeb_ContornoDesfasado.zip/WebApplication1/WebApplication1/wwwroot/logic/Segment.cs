﻿using System;
using System.Collections.Generic;
using System.Xml.Linq;

namespace WebApplication1
{
    abstract class Segment
    {
        public Shape Shape { get; set; }
        public Segment Original { get; set; }
        public Point StartPoint { get; set; }
        public Point EndPoint { get; set; }
        public Point PreviousStartPoint { get; set; }
        public Point PreviousEndPoint { get; set; }
        public Vector Orientation { get; set; }

        public Segment()
        {
        }

        public List<Intersection> CalculateIntersection(Segment segment)
        {
            List<Intersection> result = null;
            switch (GetType().Name)
            {
                case "Line":
                    switch (segment.GetType().Name)
                    {
                        case "Line":
                            result = ((Line)this).CalculateIntersectionLineLine((Line)segment);
                            break;
                        case "BezierCurve":
                            result = ((BezierCurve)segment).CalculateIntersectionBezierLine((Line)this);
                            foreach (Intersection intersection in result)
                            {   //swap intersection values
                                Intersection.PointInsideSegment p = intersection.S_PointInsideSegment;
                                
                                float t = intersection.T;
                                intersection.T = intersection.T2;                                
                                intersection.T2 = t;

                                intersection.S = (Line)this;
                                intersection.S2 = (BezierCurve)segment;

                                intersection.S_PointInsideSegment = intersection.S2_PointInsideSegment;
                                intersection.S2_PointInsideSegment = p;
                            }
                            break;
                        case "QuadraticCurve":
                            result = ((QuadraticCurve)segment).CalculateIntersectionQuadraticLine((Line)this);
                            break;
                        default:
                            throw new Exception("Intersection not computable");
                    }
                    break;
                case "BezierCurve":
                    switch (segment.GetType().Name)
                    {
                        case "Line":
                            result = ((BezierCurve)this).CalculateIntersectionBezierLine((Line)segment);
                            foreach (Intersection intersection in result)
                            {   //swap intersection values                               
                                intersection.S = (BezierCurve)this; 
                                intersection.S2 = (Line)segment;                                
                            }
                            break;
                        case "BezierCurve":
                            result = ((BezierCurve)this).CalculateIntersectionBezierBezier((BezierCurve)segment);

                            break;
                        case "QuadraticCurve":
                            result = ((QuadraticCurve)segment).CalculateIntersectionQuadraticBezier((BezierCurve)this);
                            break;
                        default:
                            throw new Exception("Intersection not computable");
                    }
                    break;
                case "QuadraticCurve":
                    switch (segment.GetType().Name)
                    {
                        case "Line":
                            result = ((QuadraticCurve)this).CalculateIntersectionQuadraticLine((Line)segment);
                            break;
                        case "BezierCurve":
                            result = ((QuadraticCurve)this).CalculateIntersectionQuadraticBezier((BezierCurve)segment);
                            break;
                        case "QuadraticCurve":
                            result = ((QuadraticCurve)this).CalculateIntersectionQuadraticQuadratic((QuadraticCurve)segment);
                            break;
                        default:
                            throw new Exception("Intersection not computable");
                    }
                    break;
                default:
                    throw new Exception("Intersection not computable");
            }
            return result;
        }

        public abstract Intersection.PointInsideSegment InSegment(Point p);

        public abstract Segment Move(float distance);

        public abstract XElement ToSVG(XNamespace ns);

        public abstract string ToSVGPath();

        public abstract Point GetMinCoordinates();

        public abstract Point GetMaxCoordinates();

        public abstract void Reverse();

        public abstract bool MoveStartPoint(Intersection p);

        public abstract bool MoveEndPoint(Intersection p);

        #region SVG Attributes
        public string Fill { get; set; }
        public string Stroke {get; set; }
        public string StrokeWidth { get; set; }
        public string StrokeLineCap { get; set; }
        public string StrokeLineJoin { get; set; }
        public string StrokeMiterLimit { get; set; }

        public void CopySVGAttributes(Segment s)
        {
            s.Fill = Fill;
            s.Stroke = Stroke;
            s.StrokeWidth = StrokeWidth;
            s.StrokeLineCap = StrokeLineCap;
            s.StrokeLineJoin = StrokeLineJoin;
            s.StrokeMiterLimit = StrokeMiterLimit;
        }

        public float Length
        { get { return (float)Math.Sqrt(Math.Pow(StartPoint.X - EndPoint.X, 2) + Math.Pow(StartPoint.Y - EndPoint.Y, 2)); } }

        #endregion
    }
}
