﻿using System;
using System.Collections.Generic;
using System.Xml.Linq;

namespace WebApplication1
{
    class QuadraticCurve : Segment
    {
        Point ControlPoint { get; set; }

        public QuadraticCurve(Point startPoint, Point controlPoint, Point endPoint) 
        {
            StartPoint = startPoint;
            EndPoint = endPoint;
            ControlPoint = controlPoint;
            Orientation = new Vector(StartPoint, EndPoint);
        }

        public override Point GetMaxCoordinates()
        {
            Point p = new Point();
            p.X = float.MinValue;
            p.Y = float.MinValue;

            if (StartPoint.X > p.X) p.X = StartPoint.X;
            if (StartPoint.Y > p.Y) p.Y = StartPoint.Y;

            if (EndPoint.X > p.X) p.X = EndPoint.X;
            if (EndPoint.Y > p.Y) p.Y = EndPoint.Y;

            if (ControlPoint.X > p.X) p.X = ControlPoint.X;
            if (ControlPoint.Y > p.Y) p.Y = ControlPoint.Y;

            return p;
        }

        public override Point GetMinCoordinates()
        {
            Point p = new Point();
            p.X = float.MinValue;
            p.Y = float.MinValue;

            if (StartPoint.X < p.X) p.X = StartPoint.X;
            if (StartPoint.Y < p.Y) p.Y = StartPoint.Y;

            if (EndPoint.X < p.X) p.X = EndPoint.X;
            if (EndPoint.Y < p.Y) p.Y = EndPoint.Y;

            if (ControlPoint.X < p.X) p.X = ControlPoint.X;
            if (ControlPoint.Y < p.Y) p.Y = ControlPoint.Y;

            return p;
        }

        public override Intersection.PointInsideSegment InSegment(Point p)
        {
            return Intersection.PointInsideSegment.Inside;
        }

        public override Segment Move(float distance)
        {
            throw new NotImplementedException();
        }

        public override bool MoveEndPoint(Intersection p)
        {
            EndPoint = p;
            Orientation = new Vector(StartPoint, EndPoint);
            return true;
        }

        public override bool MoveStartPoint(Intersection p)
        {
            StartPoint = p;
            Orientation = new Vector(StartPoint, EndPoint);
            return true;
        }

        public override void Reverse()
        {
            Point swap = EndPoint;
            EndPoint = StartPoint;
            StartPoint = swap;

            Orientation = Orientation.Reverse();
        }

        public override XElement ToSVG(XNamespace ns)
        {
            return new XElement(ns + "path",
                new XAttribute("fill", Fill),
                new XAttribute("stroke", Stroke),
                new XAttribute("stroke-width", StrokeWidth),
                new XAttribute("stroke-linecap", StrokeLineCap),
                new XAttribute("stroke-linejoin", StrokeLineJoin),
                new XAttribute("stroke-miterlimit", StrokeMiterLimit),
                new XAttribute("d", ToSVGPath())
               );
        }

        public override string ToSVGPath()
        {
            if (StartPoint.Equals(ControlPoint))
                return "M" +
                        Math.Round(StartPoint.X, 3) + "," + Math.Round(StartPoint.Y, 3) + "Q" +
                        Math.Round(ControlPoint.X, 3) + "," + Math.Round(ControlPoint.Y, 3) + "," +
                        Math.Round(EndPoint.X, 3) + "," + Math.Round(EndPoint.Y, 3);
            else if (EndPoint.Equals(ControlPoint))
                return "M" +
                        Math.Round(StartPoint.X, 3) + "," + Math.Round(StartPoint.Y, 3) + "Q" +
                        Math.Round(ControlPoint.X, 3) + "," + Math.Round(ControlPoint.Y, 3) + "," +
                        Math.Round(EndPoint.X, 3) + "," + Math.Round(EndPoint.Y, 3);
            else
                return "M" +
                        Math.Round(StartPoint.X, 3) + "," + Math.Round(StartPoint.Y, 3) + "Q" +
                        Math.Round(ControlPoint.X, 3) + "," + Math.Round(ControlPoint.Y, 3) + "," +
                        Math.Round(EndPoint.X, 3) + "," + Math.Round(EndPoint.Y, 3);
        }

        private float LinearInterpolation(float a, float b, float x)
        {
            return (a + x * (b - a));
        }

        public List<Intersection> CalculateIntersectionQuadraticLine(Line line)
        {
            float normalX = line.StartPoint.Y - line.EndPoint.Y
                , normalY = line.EndPoint.X - line.StartPoint.X
                , c2X = this.StartPoint.X + (this.ControlPoint.X * (-2f)) + this.EndPoint.X
                , c2Y = this.StartPoint.Y + (this.ControlPoint.Y * (-2f)) + this.EndPoint.Y
                , c1X = (this.StartPoint.X * (-2f)) + (this.ControlPoint.X * 2f)
                , c1Y = (this.StartPoint.Y * (-2f)) + (this.ControlPoint.Y * 2f)
                , c0X = this.StartPoint.X
                , c0Y = this.StartPoint.Y;

            //Transform line
            double coefficient = (line.StartPoint.X * line.EndPoint.Y) - (line.EndPoint.X * line.StartPoint.Y)
                 , a = (normalX * c2X) + (normalY * c2Y)
                 , b = ((normalX * c1X) + (normalY * c1Y)) / a
                 , c = ((normalX * c0X) + (normalY * c0Y) + coefficient) / a;

            //solve roots
            List<double> roots = new List<double>();
            List<Intersection> intersections = new List<Intersection>();

            double d = b * b - 4 * c;
            if (d > 0)
            {
                var e = Math.Sqrt(d);
                roots.Add((-b + Math.Sqrt(d)) / 2);
                roots.Add((-b - Math.Sqrt(d)) / 2);
            }
            else if (d == 0)
            {
                roots.Add(-b / 2);
            }


            // calc the solution points
            for (var i = 0; i < roots.Count; i++)
            {
                var minX = Math.Min(line.StartPoint.X, line.EndPoint.X);
                var minY = Math.Min(line.StartPoint.Y, line.EndPoint.Y);
                var maxX = Math.Max(line.StartPoint.X, line.EndPoint.X);
                var maxY = Math.Max(line.StartPoint.Y, line.EndPoint.Y);
                var t = roots[i];
                if (t >= 0 && t <= 1)
                {
                    // possible point -- pending bounds check
                    var pointX = LinearInterpolation(LinearInterpolation(this.StartPoint.X, this.ControlPoint.X, (float)t), LinearInterpolation(this.ControlPoint.X, this.EndPoint.X, (float)t), (float)t);
                    var pointY = LinearInterpolation(LinearInterpolation(this.StartPoint.Y, this.ControlPoint.Y, (float)t), LinearInterpolation(this.ControlPoint.Y, this.EndPoint.Y, (float)t), (float)t);

                    // bounds checks
                    if (line.StartPoint.X == line.EndPoint.X && pointY >= minY && pointY <= maxY)
                    {
                        // vertical line
                        intersections.Add(new Intersection(new Point(pointX, pointY), (float)t, -1f));
                    }
                    else if (line.StartPoint.Y == line.EndPoint.Y && pointX >= minX && pointX <= maxX)
                    {
                        // horizontal line
                        intersections.Add(new Intersection(new Point(pointX, pointY), (float)t, -1f));
                    }
                    else if (pointX >= minX && pointY >= minY && pointX <= maxX && pointY <= maxY)
                    {
                        // line passed bounds check
                        intersections.Add(new Intersection(new Point(pointX, pointY), (float)t, -1f));
                    }
                }
            }

            return intersections;
        }

        public List<Intersection> CalculateIntersectionQuadraticBezier(BezierCurve bezier)
        {
            return null;
        }

        public List<Intersection> CalculateIntersectionQuadraticQuadratic(QuadraticCurve otherQuadratic)
        {
            return null;
        }
    }
}
