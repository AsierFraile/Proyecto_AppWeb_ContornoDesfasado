﻿using System;
using System.Collections.Generic;
using System.Xml.Linq;

namespace WebApplication1
{
    class Line:Segment
    {
        public float M { get; set; }
        public float B { get; set; }

        public Line (Point onePoint, Point anotherPoint)
        {
            //x - x1      y - y1
            //------  = ---------
            //x2 - x1     y2 - y1
            
            M = (anotherPoint.Y - onePoint.Y) / (anotherPoint.X - onePoint.X);  //(y2 – y1)/ (x2 – x1)
            if (float.IsInfinity(M))
                B = onePoint.X;
            else
                B = (M * onePoint.X * -1) + onePoint.Y;       //-mx1 + y1;            

            StartPoint = new Point(onePoint);
            EndPoint = new Point(anotherPoint);
            Orientation = new Vector(StartPoint, EndPoint);
        }

        public Line (Point A, Vector V)
        {
            //x - x1   y - y1
            //------ = -------
            //  v1       v2
            M = V.Y / V.X;
            if (V.X == 0)
            {                
                B = A.X;
            }
            else
            {                 
                B = (A.Y * V.X - V.Y * A.X) / V.X;
            }

            Orientation = V;
            StartPoint = A;
            EndPoint = A.Move(V, 1);
        }

        public Line(Line oLine)
        {
            M = oLine.M;
            B = oLine.B;
            StartPoint = new Point(oLine.StartPoint);
            EndPoint = new Point(oLine.EndPoint);
            Orientation = new Vector(StartPoint, EndPoint);
            Shape = oLine.Shape;
        }

        public List<Intersection> CalculateIntersectionLineLine(Line segment)
        {
            Intersection result;
            float a1 = this.EndPoint.Y - this.StartPoint.Y;
            float b1 = this.StartPoint.X - this.EndPoint.X;
            float c1 = a1 * this.StartPoint.X + b1 * this.StartPoint.Y;

            float a2 = segment.EndPoint.Y - segment.StartPoint.Y;
            float b2 = segment.StartPoint.X - segment.EndPoint.X;
            float c2 = a2 * segment.StartPoint.X + b2 * segment.StartPoint.Y;
            
            float det = a1 * b2 - a2 * b1;
            if (det != 0)
            {
                result = new Intersection(new Point((b2 * c1 - b1 * c2) / det, 
                                                    (a1 * c2 - a2 * c1) / det),
                                          this,
                                          segment);                
                
            }
            else
            {//Default values for Parallel cases.
                result = new Intersection(new Point(float.PositiveInfinity, float.PositiveInfinity), 
                                            this, 
                                            segment);
            }

            List<Intersection> list = new List<Intersection>();
            list.Add(result);
            return list;
        }

        public override Intersection.PointInsideSegment InSegment(Point p)
        {
            Intersection.PointInsideSegment result = Intersection.PointInsideSegment.Outside;
            if (Math.Round(Math.Min(StartPoint.X, EndPoint.X), 3) <= Math.Round(p.X, 3) &&
                    Math.Round(p.X, 3) <= Math.Round(Math.Max(StartPoint.X, EndPoint.X), 3) &&
                    Math.Round(Math.Min(StartPoint.Y, EndPoint.Y), 3) <= Math.Round(p.Y, 3) &&
                    Math.Round(p.Y, 3) <= Math.Round(Math.Max(StartPoint.Y, EndPoint.Y), 3))
                result = Intersection.PointInsideSegment.Inside;

            if (p.ExactlyEquals(StartPoint) || p.ExactlyEquals(EndPoint)) result = Intersection.PointInsideSegment.Extreme;

            return result;
        }

        public override Segment Move(float distance)
        {
            Vector vStartEnd = new Vector(StartPoint, EndPoint).Unit();
            Vector vRotated = vStartEnd.Rotate((float)((!Shape.Clockwise ? 1 : -1) * Math.PI / 2)).Unit();

            Point newPoint1 = StartPoint.Move(vRotated, distance);
            Point newPoint2 = EndPoint.Move(vRotated, distance);

            Line result = new Line(newPoint1, newPoint2);
            result.Original = this;
            CopySVGAttributes(result);
            return result;
        }

        public Segment Move(Vector v, float distance)
        {
            Vector vStartEnd = new Vector(StartPoint, EndPoint).Unit();
            Vector vRotated = vStartEnd.Rotate((float)Math.PI / 2).Unit();
            
            Point newPoint1 = StartPoint.Move(vRotated, distance);            
            if (v.dotProduct(vRotated) > Math.PI/2)            
            {
                vRotated = vStartEnd.Rotate((float)-Math.PI / 2).Unit();
                newPoint1 = StartPoint.Move(vRotated, distance);
            }
            Point newPoint2 = EndPoint.Move(vRotated, distance);

            Line result = new Line(newPoint1, newPoint2);
            CopySVGAttributes(result);            
            return result;
        }

        public override string ToSVGPath()
        {
            return "M" +
                   Math.Round(StartPoint.X, 3) + "," + Math.Round(StartPoint.Y, 3) +
                   "L" +
                   Math.Round(EndPoint.X, 3) + "," + Math.Round(EndPoint.Y, 3);
        }

        public override XElement ToSVG(XNamespace ns)
        {
            return new XElement(ns + "line",
                   new XAttribute("fill", Fill),
                   new XAttribute("stroke", Stroke),
                   new XAttribute("stroke-width", StrokeWidth),
                   new XAttribute("stroke-linecap", StrokeLineCap),
                   new XAttribute("stroke-linejoin", StrokeLineJoin),
                   new XAttribute("stroke-miterlimit", StrokeMiterLimit),
                   new XAttribute("x1", Math.Round(StartPoint.X, 3)),
                   new XAttribute("y1", Math.Round(StartPoint.Y, 3)),
                   new XAttribute("x2", Math.Round(EndPoint.X, 3)),
                   new XAttribute("y2", Math.Round(EndPoint.Y, 3)));
        }

        public override Point GetMaxCoordinates()
        {
            Point p = new Point();
            p.X = float.MinValue;
            p.Y = float.MinValue;            

            if (StartPoint.X > p.X) p.X = StartPoint.X;
            if (StartPoint.Y > p.Y) p.Y = StartPoint.Y;

            if (EndPoint.X > p.X) p.X = EndPoint.X;
            if (EndPoint.Y > p.Y) p.Y = EndPoint.Y;

            return p;
        }

        public override Point GetMinCoordinates()
        {
            Point p = new Point();
            p.X = float.MaxValue;
            p.Y = float.MaxValue;

            if (StartPoint.X < p.X) p.X = StartPoint.X;
            if (StartPoint.Y < p.Y) p.Y = StartPoint.Y;

            if (EndPoint.X < p.X) p.X = EndPoint.X;
            if (EndPoint.Y < p.Y) p.Y = EndPoint.Y;

            return p;
        }

        public override void Reverse()
        {
            Point swap = EndPoint;
            EndPoint = StartPoint;
            StartPoint = swap;

            Orientation = Orientation.Reverse();
        }

        public override bool MoveStartPoint(Intersection p)
        {
            bool result = false;
            if (!StartPoint.ExactlyEquals(p))
            {
                PreviousStartPoint = StartPoint;
                Vector newOrientation = new Vector(p, EndPoint).Unit();
                StartPoint = p;
                Orientation = new Vector(StartPoint, EndPoint).Unit();
                result = true;
            }
            else
                result = true;
            return result;
        }

        public override bool MoveEndPoint(Intersection p)
        {
            bool result = false;
            if (!EndPoint.ExactlyEquals(p))
            {
                PreviousEndPoint = EndPoint;
                Vector newOrientation = new Vector(StartPoint, p).Unit();
                EndPoint = p;
                Orientation = new Vector(StartPoint, EndPoint);
                result = true;
                
            }
            else
                result = true;
            return result;
        }

        public Point GetIntermediatePoint()
        {
            Point pMax = GetMaxCoordinates();
            Point pMin = GetMinCoordinates();
            return new Point((pMax.X - pMin.X) / 2 + pMin.X,
                             (pMax.Y - pMin.Y) / 2 + pMin.Y);
        }
    }
}