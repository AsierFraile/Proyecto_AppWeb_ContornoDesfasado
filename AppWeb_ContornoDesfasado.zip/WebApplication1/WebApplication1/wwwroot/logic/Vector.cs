﻿using System;

namespace WebApplication1
{
    class Vector
    {
        public float X { get; set; }
        public float Y { get; set; }

        public Vector()
        {
            X = 1;
            Y = 0;
        }

        public Vector(float x, float y)
        {
            X = x;
            Y = y;          
        }

        public Vector(Point A, Point B) : this(B.X - A.X, B.Y - A.Y)
        {
        }

        public float Length
        { get { return (float) Math.Sqrt(Math.Pow(X, 2) + Math.Pow(Y, 2)); } }
        
        public Vector Unit()
        {
            float length = Length;
            if (length == 0.0f)
                throw new Exception("Vector.Unit(). Unitary vector cannot evaluation without length");
            return new Vector(X / length, Y / length);
        }

        public Vector Rotate(float angle)
        {
            Vector result = new Vector(
                                        (float) (X * Math.Cos(angle) - Y * Math.Sin(angle)),
                                        (float) (X * Math.Sin(angle) + Y * Math.Cos(angle))
                                );
            return result;
        }

        public float Angle
        {
            get 
            {
                float result;
                if (X == 0)
                    if (Y > 0)
                        result = (float)Math.PI/2;
                    else
                        result = (float)Math.PI*3/2;
                else
                    result = (float)Math.Atan(Y / X);
        
                if (X < 0) //3rd and 4rd quadrant
                    result += (float)Math.PI;
        
                if (result < 0) result += (float) (2 * Math.PI);
                return result;
            }
        }

        /**
         * Escalar Product or Dot Product - Producto Escalar
         * returns the angle between two vectors [0, pi]
         * Relative angle
         **/
        public float dotProduct(Vector oVector) 
        {
            double uv = (X * oVector.X) + (Y * oVector.Y);
            double luv = (Length * oVector.Length);
            double uvluv;

            if (luv == 0f) return 0f; //inf error - returns 0 degrees angle
            uvluv = Math.Round(uv / luv, 3);

            if (uvluv <= 1f && uvluv >= -1f) //arccos x range [-1, 1]
                return (float)(Math.Acos(uvluv));
            else
                return 0f;
        }

        /**
         * Cross Product to check if rotation from V1 to V2 is clockwise or counterclockwise.
         * Determinan of 2x2 Matrix.
         * return:
         * - 0        : Parallel
         * - Positive : CounterClockwise
         * - Negative : Clockwise
         */
        public float crossProduct2D(Vector oVector)
        {
            return ((X * oVector.Y) - (oVector.X * Y));
        }
        
        public static Vector operator+(Vector v1, Vector v2)
        {
            return new Vector(v1.X + v2.X, v1.Y + v2.Y);
        }

        public Vector Reverse()
        {
            return new Vector(-X, -Y);
        }

        public bool Equals(Vector v1)
        {
            return (dotProduct(v1) < 0.002f);
        }

        public static bool NearlyEqual(float a, float b, float epsilon)
        {
            float absA = Math.Abs(a);
            float absB = Math.Abs(b);
            float diff = Math.Abs(a - b);

            if (a == b)
            { // shortcut, handles infinities
                return true;
            }
            else if (a == 0 || b == 0 || absA + absB < float.MinValue)
            {
                // a or b is zero or both are extremely close to it
                // relative error is less meaningful here
                return diff < (epsilon * float.MinValue);
            }
            else
            { // use relative error
                return diff / (absA + absB) < epsilon;
            }

            /** if (Math.abs(a - b) < 0.00001) **/
        }
    }
}
