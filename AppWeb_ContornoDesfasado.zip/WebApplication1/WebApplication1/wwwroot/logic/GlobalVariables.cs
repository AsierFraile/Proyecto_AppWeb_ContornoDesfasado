﻿namespace WebApplication1
{
    public static class GlobalVariables
    {
        public static float CutOffset { get; set; }    //New Cut Offset variable
        public static float ColOffset { get; set; }    //New Collision Offset variable
        public static string Location { get; set; }    //Upload svg files folder path
        public static string SvgLocation { get; set; } //Modified svg files folder path
        public static string ZipLocation { get; set; } //Zip path
    }
}
