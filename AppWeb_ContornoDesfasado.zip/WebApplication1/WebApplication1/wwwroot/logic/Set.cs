﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Xml.Linq;
using System.Text.RegularExpressions;
using System.IO;

namespace WebApplication1
{
    class Set
    {
        public List<Shape> ShapesOriginal { get; set; }
        public List<Shape> ShapesCut { get; set; }
        public List<Shape> ShapesCollisions { get; set; }
        public List<Segment> SegmentsOriginal { get; set; }
        public string File { get; set; }
        private XElement SVGElement { get; set; }
        private XDocument SVGDocument { get; set; }
        private struct closerSegment //Estructura para la funcion OrderSegments
        {
            public Segment segment;
            public bool byStartPoint;
        }

        public Set(string sFile)
        {
            SegmentsOriginal = new List<Segment>();     //Segments parsed from SVG         
            ShapesOriginal = new List<Shape>();         //Segments sorted and split by different closed contours
            ShapesCut = new List<Shape>();             //Shapes created based on ShapesOriginal using Meta offset
            ShapesCollisions = new List<Shape>();       //Shapes created based on ShapesOriginal using Collisions offset
            File = sFile;
        }

        public void OrderSegments()
        {
            List<Segment> SegmentsCopy;
            List<Segment> shapeOrderedSegments;
            SegmentsCopy = SegmentsOriginal.ToList(); //Consuming list to move to the orderedSegment list into a proper shape within the set.                            


            List<closerSegment> closestSegments;
            closerSegment closer;
            float epsilon = 0.005f; //Range

            do //Loop to find different shapes within a SVG (Sets)
            {
                Shape aShape = new Shape();
                shapeOrderedSegments = aShape.OrderedSegments;

                SegmentsCopy[0].Shape = aShape;
                shapeOrderedSegments.Add(SegmentsCopy[0]);
                
                SegmentsCopy.Remove(SegmentsCopy[0]);
                Segment lastSegment;

                Segment closestSegment = null;
                bool bShapeClosed = false;

                //Mientras nos queden segmentos y no este la figura cerrada
                while (SegmentsCopy.Count != 0 && !bShapeClosed)//Loop by shape                    
                {
                    //Ultimo segmento de la lista
                    lastSegment = shapeOrderedSegments[shapeOrderedSegments.Count - 1];
                    closestSegments = new List<closerSegment>(); //Lista de los segmentos con un punto mas cercano al ultimo segmento.

                    while (closestSegments.Count == 0)
                    {
                        int j = 0;
                        while (j < SegmentsCopy.Count) //Bucle para buscar los segmentos mas cercanos al EndPoint del ultimo segmento
                        {
                            if (!SegmentsCopy[j].Equals(lastSegment)) //Skip Self
                            {
                                if(lastSegment.EndPoint.Distance(SegmentsCopy[j].StartPoint) <= epsilon)
                                {
                                    closer = new closerSegment();
                                    closer.segment = SegmentsCopy[j]; //Introducir en la estructura el segmento
                                    closer.byStartPoint = true;      //Marcar que el punto coincidia en el EndPoint del segmento
                                    closestSegments.Add(closer);      //Introducir en la lista los datos
                                }
                                else if (lastSegment.EndPoint.Distance(SegmentsCopy[j].EndPoint) <= epsilon)
                                {
                                    closer = new closerSegment();
                                    closer.segment = SegmentsCopy[j]; //Introducir en la estructura el segmento
                                    closer.byStartPoint = false;      //Marcar que el punto coincidia en el EndPoint del segmento
                                    closestSegments.Add(closer);      //Introducir en la lista los datos
                                }
                            }
                            ++j; //Siguiente Segmento a evaluar
                        }

                        //En caso de no encontrar ningun segmento cercano
                        if (closestSegments.Count == 0)
                        {
                            //Aumentamos la distancia en la que validamos si un punto es igual.
                            if (epsilon < 2f) //Con un maximo de 2 de distancia
                                epsilon += 0.005f;
                            else
                            {
                                Shape s = new Shape();
                                s.OrderedSegments.AddRange(SegmentsCopy);
                                epsilon = 0.005f; //Reset a valor original
                                break;
                            }
                                
                        }
                    }

                    /*Elegir segmento mas idoneo*/
                    if (closestSegments.Count == 0) bShapeClosed = true;
                    else if (closestSegments.Count == 1)
                    {
                        if (!closestSegments[0].byStartPoint)
                            closestSegments[0].segment.Reverse();

                        //Option to use this info to close adyacent segments
                        closestSegment = closestSegments[0].segment; //Asignar el segmento mas cercano
                        closestSegment.Shape = aShape;               //Asignar la shape del segmento
                        shapeOrderedSegments.Add(closestSegment);    //Agregar el segmento a la shape
                        SegmentsCopy.Remove(closestSegment);         //Borrar el segmento de la lista de copia
                        bShapeClosed = (shapeOrderedSegments[0].StartPoint.Equals(closestSegment.EndPoint)); //Comprobar si la figura esta cerrada
                    }
                    else if (closestSegments.Count > 1)
                    {
                        float dot, mindot = float.MaxValue;
                        foreach (closerSegment c in closestSegments)
                        {
                            dot = lastSegment.Orientation.dotProduct(c.segment.Orientation);
                            if (!c.byStartPoint)
                            {
                                dot = (float)Math.PI - dot;
                                c.segment.Reverse();
                            }

                            if (mindot > dot)
                            {
                                mindot = dot;
                                closestSegment = c.segment;
                            }
                        }

                        closestSegment.Shape = aShape;               //Asignar la shape del segmento
                        shapeOrderedSegments.Add(closestSegment);    //Agregar el segment a la shape
                        SegmentsCopy.Remove(closestSegment);         //Borrar el segmento de la lista de copia
                        bShapeClosed = (shapeOrderedSegments[0].StartPoint.Equals(closestSegment.EndPoint)); //Comprobar si la figura esta cerrada
                    }
                }

                //En caso de tener dos o mas segmentos en la figura.
                if (shapeOrderedSegments.Count >= 2)
                {
                    //Si la shape solo tiene dos lineas no hacer nada.
                    if (!(shapeOrderedSegments.Count == 2 && shapeOrderedSegments[0].GetType() == typeof(Line) && shapeOrderedSegments[1].GetType() == typeof(Line)))
                    {                       
                        ShapesOriginal.AddRange(aShape.SelfIntersect(true)); //Check if shape self intersects and split into shapes if it does.
                    }
                }
            }
            while (SegmentsCopy.Count != 0);
        }

        public Point GetMinCoordinates()
        {
            Point pInShape;
            Point p = new Point();
            p.X = float.MaxValue;
            p.Y = float.MaxValue;

            foreach (Shape aShape in ShapesCollisions)
            {
                pInShape = aShape.GetMinCoordinates();
                if (pInShape.X < p.X) p.X = pInShape.X;
                if (pInShape.Y < p.Y) p.Y = pInShape.Y;
            }
            return p;
        }

        public Point GetMaxCoordinates()
        {
            Point pInShape;
            Point p = new Point();
            p.X = float.MinValue;
            p.Y = float.MinValue;

            foreach (Shape aShape in ShapesCollisions)
            {
                pInShape = aShape.GetMaxCoordinates();
                if (pInShape.X > p.X) p.X = pInShape.X;
                if (pInShape.Y > p.Y) p.Y = pInShape.Y;
            }
            return p;
        }

        public void RemoveOriginalCollisionContour()
        { 
            //Remove _x30_
            var ns = SVGElement.GetDefaultNamespace();
            var frames = SVGElement.Descendants(ns + "g").Where(o => (string)o.Attribute("id") == "_x30_").ToList();
            foreach(var aFrame in frames)
            {
                aFrame.Remove();
            }

            //Remove _x30_04. External square in sockets.            
            frames = SVGElement.Descendants(ns + "g").Where(o => (string)o.Attribute("id") == "_x30_04").ToList();
            foreach (var aFrame in frames)
            {
                aFrame.Remove();
            }
        }

        public void ParseFile()
        {
            SVGDocument = XDocument.Load(File);
            SVGElement = SVGDocument.Root;

            RemoveOriginalCollisionContour();

            //Paths
            var ggPaths = (from svg_path in SVGElement.Descendants("{http://www.w3.org/2000/svg}path")
                           select svg_path).ToList();
            
            foreach (var item in ggPaths)
            {
                CreateShapeByPath(item);
            }

            //Lines
            var ggLines = (from svg_path in SVGElement.Descendants("{http://www.w3.org/2000/svg}line")
                           select svg_path).ToList();
            foreach (var item in ggLines)
            {
                var line = CreateLine(item);
                if (line != null)
                {
                    SegmentsOriginal.Add(line);                    
                }
            }

            var ggPolylines = (from svg_path in SVGElement.Descendants("{http://www.w3.org/2000/svg}polyline")
                           select svg_path).ToList();
            foreach (var item in ggPolylines)
            {
                var polyline = CreatePolyLine(item);
                if (polyline != null)
                {
                    SegmentsOriginal.AddRange(polyline);
                }
            }
        }

        private void CreateShapeByPath(XElement item)
        {            
            List<Line> lines = new List<Line>();

            string path = item.Attribute("d").Value;
            string[] instructions = Regex.Split(path.Trim(), @"(?=[cClLMsSzZvVhH,-])");

            Point firstM = null;
            Point lastM = new Point();
            Vector lastBezierVector = new Vector();
            Point bezierStartPoint = new Point();
            Point bezierEndPoint = new Point();
            Point endPoint = new Point();
            Line line;

            int i = 0;            
            do
            {
                if (instructions[i].Length > 0)
                {
                    switch (instructions[i][0])
                    {
                        case 'M':
                            lastM = new Point(float.Parse(instructions[i++].Substring(1)), 
                                              float.Parse(instructions[i][0] == ',' ? instructions[i++].Substring(1) : instructions[i++]));
                            if (firstM == null) firstM = lastM;
                            lastBezierVector = null;
                            break;
                        case 'c':
                            if (instructions[i] == "c") i++;

                            bezierStartPoint = new Point(float.Parse((instructions[i][0] == ',' || instructions[i][0] == 'c') ? instructions[i++].Substring(1) : instructions[i++]),
                                                         float.Parse(instructions[i][0] == ',' ? instructions[i++].Substring(1) : instructions[i++])
                                                         );
                            bezierEndPoint = new Point(float.Parse(instructions[i][0] == ',' ? instructions[i++].Substring(1) : instructions[i++]),
                                                       float.Parse(instructions[i][0] == ',' ? instructions[i++].Substring(1) : instructions[i++])
                                                       );
                            endPoint = new Point(float.Parse(instructions[i][0] == ',' ? instructions[i++].Substring(1) : instructions[i++]),
                                                 float.Parse(instructions[i][0] == ',' ? instructions[i++].Substring(1) : instructions[i++])
                                                 );

                            Point zero = new Point(0, 0);
                            if (
                                (endPoint.ExactlyEquals(bezierStartPoint) && endPoint.ExactlyEquals(bezierEndPoint)) ||
                                (zero.ExactlyEquals(bezierStartPoint) && zero.ExactlyEquals(bezierEndPoint))
                                )
                            {                                
                                if (!lastM.ExactlyEquals(endPoint))
                                {
                                    line = new Line(lastM, endPoint);
                                    line.Fill = item.Attribute("fill").Value;
                                    line.Stroke = item.Attribute("stroke").Value;
                                    line.StrokeWidth = "0.1"; //item.Attribute("stroke-width").Value;
                                    line.StrokeLineCap = item.Attribute("stroke-linecap").Value;
                                    line.StrokeLineJoin = item.Attribute("stroke-linejoin").Value;
                                    line.StrokeMiterLimit = item.Attribute("stroke-miterlimit").Value;

                                    SegmentsOriginal.Add(line);
                                }
                            }
                            else
                            {
                                BezierCurve arcRelative = new BezierCurve(lastM,
                                                                         bezierStartPoint,
                                                                         bezierEndPoint,
                                                                         endPoint,
                                                                         true);
                                arcRelative.Fill = item.Attribute("fill").Value;
                                arcRelative.Stroke = item.Attribute("stroke").Value;
                                arcRelative.StrokeWidth = "0.1"; //item.Attribute("stroke-width").Value;
                                arcRelative.StrokeLineCap = item.Attribute("stroke-linecap").Value;
                                arcRelative.StrokeLineJoin = item.Attribute("stroke-linejoin").Value;
                                arcRelative.StrokeMiterLimit = item.Attribute("stroke-miterlimit").Value;

                                SegmentsOriginal.Add(arcRelative);
                            }
                            
                            lastM = lastM.Move(new Vector(endPoint.X, endPoint.Y), 1);
                            lastBezierVector = new Vector(endPoint, bezierEndPoint);
                            break;
                        case 'C':
                            if (instructions[i] == "C") i++;

                            bezierStartPoint = new Point(float.Parse((instructions[i][0] == ',' || instructions[i][0] == 'C') ? instructions[i++].Substring(1) : instructions[i++]), 
                                                         float.Parse(instructions[i][0] == ',' ? instructions[i++].Substring(1) : instructions[i++])
                                                         );
                            bezierEndPoint = new Point(float.Parse(instructions[i][0] == ',' ? instructions[i++].Substring(1) : instructions[i++]), 
                                                       float.Parse(instructions[i][0] == ',' ? instructions[i++].Substring(1) : instructions[i++])
                                                       );
                            endPoint = new Point(float.Parse(instructions[i][0] == ',' ? instructions[i++].Substring(1) : instructions[i++]), 
                                                 float.Parse(instructions[i][0] == ',' ? instructions[i++].Substring(1) : instructions[i++])
                                                 );

                            if (
                                (endPoint.ExactlyEquals(bezierStartPoint) && endPoint.ExactlyEquals(bezierEndPoint)) ||
                                (lastM.ExactlyEquals(bezierStartPoint) && lastM.ExactlyEquals(bezierEndPoint))
                                )
                            {
                                if (!lastM.ExactlyEquals(endPoint))
                                {
                                    line = new Line(lastM, endPoint);
                                    line.Fill = item.Attribute("fill").Value;
                                    line.Stroke = item.Attribute("stroke").Value;
                                    line.StrokeWidth = "0.1"; //item.Attribute("stroke-width").Value;
                                    line.StrokeLineCap = item.Attribute("stroke-linecap").Value;
                                    line.StrokeLineJoin = item.Attribute("stroke-linejoin").Value;
                                    line.StrokeMiterLimit = item.Attribute("stroke-miterlimit").Value;

                                    SegmentsOriginal.Add(line);
                                }
                            }
                            else
                            {
                                BezierCurve arcAbsolute = new BezierCurve(lastM,
                                                                     bezierStartPoint,
                                                                     bezierEndPoint,
                                                                     endPoint,
                                                                     false);
                                arcAbsolute.Fill = item.Attribute("fill").Value;
                                arcAbsolute.Stroke = item.Attribute("stroke").Value;
                                arcAbsolute.StrokeWidth = "0.1"; //item.Attribute("stroke-width").Value;
                                arcAbsolute.StrokeLineCap = item.Attribute("stroke-linecap").Value;
                                arcAbsolute.StrokeLineJoin = item.Attribute("stroke-linejoin").Value;
                                arcAbsolute.StrokeMiterLimit = item.Attribute("stroke-miterlimit").Value;

                                SegmentsOriginal.Add(arcAbsolute);
                            }
                            
                            lastM = endPoint;
                            lastBezierVector = new Vector(endPoint, bezierEndPoint);
                            break;
                        case '-':
                            throw new Exception("Number not handled in previous elements");
                        case ',':
                            throw new Exception("Element not handled in previous elements");
                        case 'L':                        
                            if (instructions[i] == "L") i++;

                            endPoint = new Point(float.Parse((instructions[i][0] == ',' || instructions[i][0] == 'L' ) ? instructions[i++].Substring(1) : instructions[i++]), float.Parse(instructions[i][0] == ',' ? instructions[i++].Substring(1) : instructions[i++]));
                            line = new Line(lastM, endPoint);
                            line.Fill = item.Attribute("fill").Value;
                            line.Stroke = item.Attribute("stroke").Value;
                            line.StrokeWidth = "0.1"; //item.Attribute("stroke-width").Value;
                            line.StrokeLineCap = item.Attribute("stroke-linecap").Value;
                            line.StrokeLineJoin = item.Attribute("stroke-linejoin").Value;
                            line.StrokeMiterLimit = item.Attribute("stroke-miterlimit").Value;

                            if (!line.StartPoint.Equals(line.EndPoint))
                            {
                                SegmentsOriginal.Add(line);
                            }

                            lastM = endPoint;
                            lastBezierVector = null;
                            break;
                        case 'l':
                            if (instructions[i] == "l") i++;

                            endPoint = new Point(float.Parse((instructions[i][0] == ',' || instructions[i][0] == 'l') ? instructions[i++].Substring(1) : instructions[i++]), float.Parse(instructions[i][0] == ',' ? instructions[i++].Substring(1) : instructions[i++]));
                            endPoint = endPoint.Move(new Vector(lastM.X, lastM.Y), 1);                                                        

                            line = new Line(lastM, endPoint);
                            line.Fill = item.Attribute("fill").Value;
                            line.Stroke = item.Attribute("stroke").Value;
                            line.StrokeWidth = "0.1"; //item.Attribute("stroke-width").Value;
                            line.StrokeLineCap = item.Attribute("stroke-linecap").Value;
                            line.StrokeLineJoin = item.Attribute("stroke-linejoin").Value;
                            line.StrokeMiterLimit = item.Attribute("stroke-miterlimit").Value;

                            if (!line.StartPoint.Equals(line.EndPoint))
                            {
                                SegmentsOriginal.Add(line);
                            }

                            lastM = endPoint;
                            lastBezierVector = null;
                            break;
                        case 'Q':
                            throw new Exception("Not implemented");
                        case 'A':
                            throw new Exception("Not implemented");
                        case 's':
                            if (instructions[i] == "s") i++;

                            bezierEndPoint = new Point(float.Parse((instructions[i][0] == ',' || instructions[i][0] == 's') ? instructions[i++].Substring(1) : instructions[i++]), float.Parse(instructions[i][0] == ',' ? instructions[i++].Substring(1) : instructions[i++]));
                            endPoint = new Point(float.Parse(instructions[i][0] == ',' ? instructions[i++].Substring(1) : instructions[i++]), float.Parse(instructions[i][0] == ',' ? instructions[i++].Substring(1) : instructions[i++]));

                            
                            BezierCurve smoothArcRelative = new BezierCurve(lastM,
                                                                         (lastBezierVector == null ? null : new Point(-lastBezierVector.X, -lastBezierVector.Y)),
                                                                         bezierEndPoint,
                                                                         endPoint,
                                                                         true);
                            smoothArcRelative.Fill = item.Attribute("fill").Value;
                            smoothArcRelative.Stroke = item.Attribute("stroke").Value;
                            smoothArcRelative.StrokeWidth = "0.1"; //item.Attribute("stroke-width").Value;
                            smoothArcRelative.StrokeLineCap = item.Attribute("stroke-linecap").Value;
                            smoothArcRelative.StrokeLineJoin = item.Attribute("stroke-linejoin").Value;
                            smoothArcRelative.StrokeMiterLimit = item.Attribute("stroke-miterlimit").Value;

                            SegmentsOriginal.Add(smoothArcRelative);
                            
                            lastM = lastM.Move(new Vector(endPoint.X, endPoint.Y), 1);
                            lastBezierVector = new Vector(endPoint, bezierEndPoint);
                            break;
                        case 'S':
                            if (instructions[i] == "S") i++;

                            bezierEndPoint = new Point(float.Parse((instructions[i][0] == ',' || instructions[i][0] == 'S') ? instructions[i++].Substring(1) : instructions[i++]), float.Parse(instructions[i][0] == ',' ? instructions[i++].Substring(1) : instructions[i++]));
                            endPoint = new Point(float.Parse(instructions[i][0] == ',' ? instructions[i++].Substring(1) : instructions[i++]), float.Parse(instructions[i][0] == ',' ? instructions[i++].Substring(1) : instructions[i++]));

                            
                            BezierCurve smoothArcAbsolute = new BezierCurve(lastM,
                                                                         (lastBezierVector == null ? null : lastM.Move(lastBezierVector, -1)),
                                                                         bezierEndPoint,
                                                                         endPoint,
                                                                         false);
                            smoothArcAbsolute.Fill = item.Attribute("fill").Value;
                            smoothArcAbsolute.Stroke = item.Attribute("stroke").Value;
                            smoothArcAbsolute.StrokeWidth = "0.1"; //item.Attribute("stroke-width").Value;
                            smoothArcAbsolute.StrokeLineCap = item.Attribute("stroke-linecap").Value;
                            smoothArcAbsolute.StrokeLineJoin = item.Attribute("stroke-linejoin").Value;
                            smoothArcAbsolute.StrokeMiterLimit = item.Attribute("stroke-miterlimit").Value;

                            SegmentsOriginal.Add(smoothArcAbsolute);
                            
                            lastM = endPoint;
                            lastBezierVector = new Vector(endPoint, bezierEndPoint);
                            break;
                        case 'z':
                        case 'Z':
                            line = new Line(lastM, firstM);
                            line.Fill = item.Attribute("fill").Value;
                            line.Stroke = item.Attribute("stroke").Value;
                            line.StrokeWidth = "0.1"; //item.Attribute("stroke-width").Value;
                            line.StrokeLineCap = item.Attribute("stroke-linecap").Value;
                            line.StrokeLineJoin = item.Attribute("stroke-linejoin").Value;
                            line.StrokeMiterLimit = item.Attribute("stroke-miterlimit").Value;

                            if (!line.StartPoint.Equals(line.EndPoint))
                            {
                                SegmentsOriginal.Add(line);
                            }

                            lastM = endPoint;

                            i++;
                            break;
                        case 'v':
                            if (instructions[i] == "v") i++;
                            endPoint = new Point(lastM.X, lastM.Y + (float.Parse((instructions[i][0] == 'v') ? instructions[i++].Substring(1) : instructions[i++])));
                            line = new Line(lastM, endPoint);

                            line.Fill = item.Attribute("fill").Value;
                            line.Stroke = item.Attribute("stroke").Value;
                            line.StrokeWidth = "0.1"; //item.Attribute("stroke-width").Value;
                            line.StrokeLineCap = item.Attribute("stroke-linecap").Value;
                            line.StrokeLineJoin = item.Attribute("stroke-linejoin").Value;
                            line.StrokeMiterLimit = item.Attribute("stroke-miterlimit").Value;

                            if (!line.StartPoint.Equals(line.EndPoint))
                            {
                                SegmentsOriginal.Add(line);                                
                            }

                            lastM = endPoint;
                            lastBezierVector = null;
                            break;
                        case 'V':
                            if (instructions[i] == "V") i++;
                            endPoint = new Point(lastM.X, (float.Parse((instructions[i][0] == 'V') ? instructions[i++].Substring(1) : instructions[i++])));

                            line = new Line(lastM, endPoint);

                            line.Fill = item.Attribute("fill").Value;
                            line.Stroke = item.Attribute("stroke").Value;
                            line.StrokeWidth = "0.1"; //item.Attribute("stroke-width").Value;
                            line.StrokeLineCap = item.Attribute("stroke-linecap").Value;
                            line.StrokeLineJoin = item.Attribute("stroke-linejoin").Value;
                            line.StrokeMiterLimit = item.Attribute("stroke-miterlimit").Value;

                            if (!line.StartPoint.Equals(line.EndPoint))
                            {
                                SegmentsOriginal.Add(line);                                
                            }

                            lastM = endPoint;
                            lastBezierVector = null;
                            break;
                        case 'h':
                            if (instructions[i] == "h") i++;
                            endPoint = new Point(lastM.X + float.Parse((instructions[i][0] == 'h') ? instructions[i++].Substring(1) : instructions[i++]), lastM.Y);

                            line = new Line(lastM, endPoint);

                            line.Fill = item.Attribute("fill").Value;
                            line.Stroke = item.Attribute("stroke").Value;
                            line.StrokeWidth = "0.1"; //item.Attribute("stroke-width").Value;
                            line.StrokeLineCap = item.Attribute("stroke-linecap").Value;
                            line.StrokeLineJoin = item.Attribute("stroke-linejoin").Value;
                            line.StrokeMiterLimit = item.Attribute("stroke-miterlimit").Value;

                            if (!line.StartPoint.Equals(line.EndPoint))
                            {
                                SegmentsOriginal.Add(line);                                
                            }

                            lastM = endPoint;
                            lastBezierVector = null;
                            break;
                        case 'H':
                            if (instructions[i] == "H") i++;
                            endPoint = new Point(float.Parse((instructions[i][0] == 'H') ? instructions[i++].Substring(1) : instructions[i++]), lastM.Y);
                            line = new Line(lastM, endPoint);

                            line.Fill = item.Attribute("fill").Value;
                            line.Stroke = item.Attribute("stroke").Value;
                            line.StrokeWidth = "0.1"; //item.Attribute("stroke-width").Value;
                            line.StrokeLineCap = item.Attribute("stroke-linecap").Value;
                            line.StrokeLineJoin = item.Attribute("stroke-linejoin").Value;
                            line.StrokeMiterLimit = item.Attribute("stroke-miterlimit").Value;

                            if (!line.StartPoint.Equals(line.EndPoint))
                            {
                                SegmentsOriginal.Add(line);                               
                            }
                            lastM = endPoint;
                            lastBezierVector = null;
                            break;

                        default:
                            throw new Exception("SVG tag not identified");
                    }
                }
                else i++;
            }
            while (i < instructions.Count());            
        }

        private Line CreateLine(XElement item)
        {
            Point startPoint = new Point(float.Parse(item.Attribute("x1").Value), float.Parse(item.Attribute("y1").Value));
            Point endPoint = new Point(float.Parse(item.Attribute("x2").Value), float.Parse(item.Attribute("y2").Value));
            Line line = new Line(startPoint, endPoint);
            line.Fill = item.Attribute("fill").Value;
            line.Stroke = item.Attribute("stroke").Value;
            line.StrokeWidth = "0.1"; //item.Attribute("stroke-width").Value;
            line.StrokeLineCap = item.Attribute("stroke-linecap").Value;
            line.StrokeLineJoin = item.Attribute("stroke-linejoin").Value;
            line.StrokeMiterLimit = item.Attribute("stroke-miterlimit").Value;

            if (line.StartPoint.Equals(line.EndPoint))
                return null;
            else
                return line;
        }

        private List<Line> CreatePolyLine(XElement item)
        {
            List<Line> result = new List<Line>();

            string path = item.Attribute("points").Value;
            string[] points = Regex.Split(path.Trim(), @" ");
            Point startPoint, endPoint;
            startPoint = endPoint = null;

            foreach (string i in points)
            {
                if (i.Trim().Length > 0)
                {
                    string[] coords = Regex.Split(i, @",");
                    if (startPoint == null)
                    {
                        startPoint = new Point(float.Parse(coords[0]), float.Parse(coords[1]));
                    }
                    else
                    {
                        endPoint = new Point(float.Parse(coords[0]), float.Parse(coords[1]));
                        Line line = new Line(startPoint, endPoint);
                        startPoint = endPoint;
                        line.Fill = item.Attribute("fill").Value;
                        line.Stroke = item.Attribute("stroke").Value;
                        line.StrokeWidth = "0.1"; //item.Attribute("stroke-width").Value;
                        line.StrokeLineCap = item.Attribute("stroke-linecap").Value;
                        line.StrokeLineJoin = item.Attribute("stroke-linejoin").Value;
                        line.StrokeMiterLimit = item.Attribute("stroke-miterlimit").Value;
                        if (!line.StartPoint.Equals(line.EndPoint))
                            result.Add(line);
                    }
                }
            }
            return result;
        }

        public void SetDimensions()
        {
            Point min = GetMinCoordinates();
            Point max = GetMaxCoordinates();
            Point min_v = new Point();
            Point max_v = new Point();

            //Include some margins
            max_v.X = max.X + Math.Abs(min.X);
            max_v.Y = max.Y + Math.Abs(min.Y);

            SVGElement.SetAttributeValue("x", min.X + "px");
            SVGElement.SetAttributeValue("y", min.Y + "px");
            SVGElement.SetAttributeValue("width", max.X + "px");
            SVGElement.SetAttributeValue("height", max.Y + "px");

            SVGElement.SetAttributeValue("viewBox", min.X + " " +
                                                    min.Y + " " +
                                                    max_v.X + " " +
                                                    max_v.Y);

        }

        public string ToSVGPath(int option)
        {
            List<Shape> list = null;
            switch (option)
            {
                case 1:
                    list = ShapesOriginal;
                    break;
                case 2:
                    list = ShapesCut;
                    break;
                case 3:
                    list = ShapesCollisions;
                    break;
                default:
                    list = ShapesOriginal;
                    break;
            }


            string sResult = "";
            foreach (Shape shape in list)
            {
                XElement gShape = new XElement(SVGElement.Name.Namespace + "g", new XAttribute("id", (shape.Clockwise ? "Clockwise" : "Counter Clockwise")));
                foreach (Segment external in shape.OrderedSegments)
                {
                    sResult += external.ToSVGPath();
                }                
            }
            return sResult;
        }

        public void DumpShapesIntoSVG()
        {
            XElement globalGroupCollision = new XElement(SVGElement.Name.Namespace + "g", new XAttribute("id", "_x30_Collision"));
            XElement globalGroupMeta = new XElement(SVGElement.Name.Namespace + "g", new XAttribute("id", "_x30_Meta"));
            
            foreach(Shape shape in ShapesCollisions)
            {
                XElement gShape = new XElement(SVGElement.Name.Namespace + "g", new XAttribute("id", (shape.Clockwise?"Clockwise": "Counter Clockwise")));
                foreach (Segment external in shape.OrderedSegments)
                {
                    globalGroupCollision.Add("\r\n");
                    gShape.Add(external.ToSVG(SVGElement.Name.Namespace));                    
                }
                globalGroupCollision.Add(gShape);
            }

            foreach (Shape shape in ShapesCut)
            {
                foreach (Segment meta in shape.OrderedSegments)
                {
                    globalGroupMeta.Add("\r\n");
                    globalGroupMeta.Add(meta.ToSVG(SVGElement.Name.Namespace));
                }
            }

            globalGroupCollision.Add("\r\n");
            globalGroupMeta.Add("\r\n");

            SVGElement.Add(globalGroupCollision);
            SVGElement.Add(globalGroupMeta);
        }

        public void ProcessShapes(bool bFixContour)
        {
            Shape tempShape;
            foreach (Shape oShape in ShapesOriginal)
            {
                tempShape = oShape.CalculateExternalContour(true);
                if (bFixContour) tempShape.FixContour(true);
                if (tempShape.OrderedSegments.Count > 1) ShapesCollisions.Add(tempShape);

                tempShape = oShape.CalculateExternalContour(false);
                if (bFixContour) tempShape.FixContour(false);
                if (tempShape.OrderedSegments.Count > 1) ShapesCut.Add(tempShape);
            }
        }

        public void ShapesCollisionsToLines()
        {
            List<Shape> shapes = new List<Shape>();            
            Shape newShape;
            Point lastPoint;
            foreach(Shape aShape in ShapesCollisions)
            {
                lastPoint = null;
                newShape = new Shape();
                newShape.Clockwise = aShape.Clockwise;
                foreach(Segment aSegment in aShape.OrderedSegments)
                {                    
                    switch (aSegment.GetType().Name)
                    {
                        case "Line":
                            if (lastPoint != null && !aSegment.StartPoint.ExactlyEquals(lastPoint))
                            {
                                if (!aSegment.EndPoint.ExactlyEquals(lastPoint))
                                {
                                    aSegment.MoveStartPoint(new Intersection(lastPoint));
                                    newShape.OrderedSegments.Add(aSegment);
                                }                                
                            }
                            else
                                newShape.OrderedSegments.Add(aSegment);
                            lastPoint = aSegment.EndPoint;
                            break;
                        case "BezierCurve":
                            List<Line> lines = ((BezierCurve) aSegment).ToLines();

                            foreach (Line l in lines)
                            {
                                if (lastPoint != null && !l.StartPoint.ExactlyEquals(lastPoint))
                                {
                                    if (!l.EndPoint.ExactlyEquals(lastPoint))
                                    { 
                                        l.MoveStartPoint(new Intersection(lastPoint));
                                        newShape.OrderedSegments.Add(l);
                                    }
                                }
                                else
                                    newShape.OrderedSegments.Add(l);
                                lastPoint = l.EndPoint;                                
                            }
                            break;
                        case "QuadraticCurve":
                            throw new Exception("QuadraticCurve to lines not implemented");
                        default:
                            throw new Exception("Segment not computable");
                    }                    
                }
                if (lastPoint != null && !newShape.OrderedSegments[0].StartPoint.ExactlyEquals(lastPoint)) newShape.OrderedSegments[0].MoveStartPoint(new Intersection(lastPoint));
                shapes.Add(newShape);
            }
            ShapesCollisions = shapes;
        }

        public string Save(string strPath)
        {
            int slen = File.Length - 4;
            string fname = File.Substring(0, slen);

            fname += ".svg";
            fname = fname.Replace("-meta", "");
            
            if (!Directory.Exists(strPath))
                Directory.CreateDirectory(strPath);

            SVGDocument.Save(strPath + Path.GetFileName(fname));

            return strPath + Path.GetFileName(fname);
        }

        public void OrderShapes(bool choice)
        {
            List<Shape> list;
            if (choice) list = ShapesCut;
            else list = ShapesCollisions;

            List<Shape> remove = new List<Shape>();

            //Hacer polinomios de las shapes
            foreach (Shape s in list)
                s.ToPoly();            

            
            int i = 0;
            int j = 0;
            bool bRepeat = false;
            do
            {
                bRepeat = false;
                i = 0;
                do
                {
                    j = 0;
                    while (j < list.Count())
                    {
                        if (i != j)
                        {
                            switch (list[i].PolyInPoly(list[j]))
                            {
                                case Shape.PolygonInsidePolygon.Inside:
                                case Shape.PolygonInsidePolygon.TangentInside:
                                    list.Remove(list[j]);
                                    if (j < i) i--;
                                    bRepeat = true;
                                    break;
                                case Shape.PolygonInsidePolygon.Outside:
                                case Shape.PolygonInsidePolygon.TangentOutside:
                                    j++;
                                    break;
                                case Shape.PolygonInsidePolygon.Intersect:
                                    if (list[i].Union(list[j]))
                                    {
                                        list.Remove(list[j]);
                                        if (j < i) i--;
                                        bRepeat = true;
                                    }
                                    else
                                        j++;
                                    break;
                                case Shape.PolygonInsidePolygon.Undefined:
                                    list.Remove(list[j]);

                                    if (j < i) i--;
                                    bRepeat = true;
                                    break;
                            }
                        }
                        else j++;
                    }
                    i++;
                } while (i < list.Count());
            } while (bRepeat);
        }
    }
}