﻿using System;

namespace WebApplication1
{
    class Point : IEquatable<Point>
    {
        public float X { get; set; }
        public float Y { get; set; }

        public Point ()
        {
            X = 0;
            Y = 0;
        }

        public Point (float x, float y)
        {
            X = (float)Math.Round(x, 3);
            Y = (float)Math.Round(y, 3);
        }

        public Point(Point point)
        {
            X = point.X;
            Y = point.Y;
        }
        
        public static Point CalculateCircleCenter(Point A, Point B, Point C)
        {
            Point D = new Point(A);
            Point E = new Point(B);
            D.X -= C.X;
            D.Y -= C.Y;
            E.X -= C.X;
            E.Y -= C.Y;

            Point Z = new Point (D.X * D.X + D.Y * D.Y, E.X * E.X + E.Y * E.Y);
            float d = 2 * (D.X * E.Y - E.X * D.Y);

            Point center = new Point((Z.X * E.Y - Z.Y * D.Y) / d + C.X, (D.X * Z.Y - E.X * Z.X) / d + C.Y);
            return center;
        }

        public Point Move(Vector vector, float distance)
        {
            return new Point (X + (vector.X * distance), Y + (vector.Y * distance));
        }

        public bool Equals(Point p1)
        {
            if (p1 == null) return false;
            return NearlyEqual(p1.X, X, 0.00051f) && NearlyEqual(p1.Y, Y, 0.0005f);
        }

        public bool Equals(Point p1, float epsilon)
        {
            if (p1 == null) return false;
            return NearlyEqual(p1.X, X, epsilon) && NearlyEqual(p1.Y, Y, epsilon);
        }

        public bool ExactlyEquals(Point p1)
        {
            return (p1.X == X && p1.Y == Y);            
        }

        public float Distance(Point p1)
        {
            Vector v = new Vector(this, p1);
            return v.Length;
        }

        /**
         * Fail Cases:
         * - When both a and b are zero. 0.0/0.0 is “not a number”, which causes an exception on some platforms, or returns false for all comparisons.
         * - When only b is zero, the division yields “infinity”, which may also cause an exception, or is greater than epsilon even when a is smaller.
         * - It returns false when both a and b are very small but on opposite sides of zero, even when they’re the smallest possible non-zero numbers.
         **/
        public static bool NearlyEqual(float a, float b, float epsilon)
        {
            float absA = Math.Abs(a);
            float absB = Math.Abs(b);
            float diff = Math.Abs(a - b);
        
            if (a == b)
            { // shortcut, handles infinities
                return true;
            }
            else if (a == 0 || b == 0 || absA + absB < float.MinValue)
            {
                // a or b is zero or both are extremely close to it
                // relative error is less meaningful here
                return diff < (epsilon * float.MinValue);
            }
            else
            { // use relative error
                return diff / (absA + absB) < epsilon;
            }
        
            /** if (Math.abs(a - b) < 0.00001) **/
        }
    }
}
