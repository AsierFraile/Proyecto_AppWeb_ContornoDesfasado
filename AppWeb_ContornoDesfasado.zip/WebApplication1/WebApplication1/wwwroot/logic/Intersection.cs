﻿namespace WebApplication1
{
    class Intersection : Point
    {
        public float T { get; set; }
        public float T2 { get; set; }
        public Segment S { get; set; }
        public PointInsideSegment S_PointInsideSegment { get; set; }
        public Segment S2 { get; set; }
        public PointInsideSegment S2_PointInsideSegment { get; set; }
        public bool Set { get; set; }
        public enum PointInsideSegment
        {
            Extreme,
            Outside,
            Inside
        }

        public Intersection() : base()
        {
            T = -1f;
            T2 = -1f;
        }
        public Intersection(float x, float y) : base(x, y) 
        {
            T = -1f;
            T2 = -1f;
        }
        
        public Intersection(Intersection intersection) : base(intersection) 
        {
            T = intersection.T;
            T = intersection.T2;
        }

        public Intersection(Point point) : base(point)
        {
            T = -1f;
            T2 = -1f;
        }

        public Intersection(Point point, float t, float t2) : base(point)
        {
            T = t;
            T2 = t2;
        }

        public Intersection(Point point, Segment s, Segment s2) : base(point)
        {
            S = s;
            S2 = s2;

            S_PointInsideSegment = S.InSegment(point);
            S2_PointInsideSegment = S2.InSegment(point);
        }

        public Intersection(Point point, float t, float t2, Segment s, Segment s2) : base(point)
        {
            T = t;
            T2 = t2;
            S = s;
            S2 = s2;
            S_PointInsideSegment = S.InSegment(point);
            S2_PointInsideSegment = S2.InSegment(point);
        }
    }
}
