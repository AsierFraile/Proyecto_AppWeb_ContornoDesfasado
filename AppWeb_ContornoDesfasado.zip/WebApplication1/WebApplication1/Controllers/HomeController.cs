﻿using System;
using System.Diagnostics;
using System.IO;
using System.IO.Compression;
using System.Linq;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using WebApplication1.Models;

namespace WebApplication1.Controllers
{
    public class HomeController : Controller
    {
        private IHostingEnvironment hostingEnv;

        public HomeController(IHostingEnvironment env)
        {
            this.hostingEnv = env;
        }

        public IActionResult Index()
        {
            return View();
        }

        public IActionResult About()
        {
            ViewData["Message"] = "Your application description page.";

            return View();
        }

        public IActionResult Contact()
        {
            ViewData["Message"] = "Your contact page.";

            return View();
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }

        [HttpPost]
        public IActionResult UploadFiles()
        {
            long size = 0;
            var files = Request.Form.Files;

            //Crear Directorio para almacenar los archivos
            if (!Directory.Exists(hostingEnv.WebRootPath + $@"\UploadedFiles"))
                Directory.CreateDirectory(hostingEnv.WebRootPath + $@"\UploadedFiles");

            foreach (var file in files)
            {
                string filename = hostingEnv.WebRootPath + $@"\UploadedFiles\{file.FileName}";
                size += file.Length; //bytes
                using (FileStream fs = System.IO.File.Create(filename))
                {
                    file.CopyTo(fs);
                    fs.Flush();
                }
            }

            string message;
            if (files.Count > 1)
                message = $"Los {files.Count} archivos han sido cargados correctamente!";
            else
                message = $"El archivo ha sido cargado correctamente!";
            return Json(message);
        }

        [HttpPost]
        public IActionResult DownloadFiles()
        {
            //define directory variables
            GlobalVariables.Location = hostingEnv.WebRootPath + $@"\UploadedFiles\";
            GlobalVariables.SvgLocation = hostingEnv.WebRootPath + $@"\ModifiedFiles\";
            GlobalVariables.ZipLocation = hostingEnv.WebRootPath + $@"\SVG_Modificados.zip";

            //define modify variables
            GlobalVariables.CutOffset = float.Parse(Request.Form["cutOffset"]); //input
            GlobalVariables.ColOffset = float.Parse(Request.Form["colOffset"]); //input

            if (!Directory.Exists(GlobalVariables.Location))
                Directory.CreateDirectory(GlobalVariables.Location);

            var files = Directory.GetFiles(GlobalVariables.Location);
            if (files.Count() < 1) //No files Error
                return RedirectToAction("Index");

            else
            {
                //Crear Directorio para almacenar los archivos modificados
                if (!Directory.Exists(GlobalVariables.SvgLocation))
                    Directory.CreateDirectory(GlobalVariables.SvgLocation);

                //SVG PROGRAM
                Set m_set;
                for (int i = 0; i < files.Length; ++i)
                {
                    try
                    {
                        //Check file format
                        if (files[i].EndsWith(".svg") || files[i].EndsWith(".SVG"))
                        {
                            m_set = new Set(files[i]);
                            m_set.ParseFile();
                            m_set.OrderSegments();
                            m_set.ProcessShapes(true);        //True: Fix Contour, False: No fix Contour
                            m_set.ShapesCollisionsToLines();
                            m_set.OrderShapes(false);         //False: ShapesCollision, True: ShapesMeta
                            m_set.DumpShapesIntoSVG();
                            m_set.SetDimensions();
                            m_set.Save(GlobalVariables.SvgLocation);
                        }
                        else
                            throw new Exception("Wrong File Format.");
                    }
                    catch (Exception e) //Capturar errores y clasificarlos en carpetas.
                    {
                        string sFolder = GlobalVariables.SvgLocation + e.Message.Replace("\r", "").Replace("\n", "").Replace(":", "");
                        if (!Directory.Exists(sFolder))
                            Directory.CreateDirectory(sFolder);

                        System.IO.File.Move(files[i], sFolder + "\\" + Path.GetFileName(files[i]));
                    }
                }
            }

            //Comprobar si hay un zip con el mismo nombre
            files = Directory.GetFiles(hostingEnv.WebRootPath);
            foreach (string file in files)
                if (file.Contains("SVG_Modificados.zip"))
                    System.IO.File.Delete(file);
            
            //Crear Zip
            ZipFile.CreateFromDirectory(GlobalVariables.SvgLocation, GlobalVariables.ZipLocation);

            //leer todos los bytes del Zip
            byte[] bytes = System.IO.File.ReadAllBytes(GlobalVariables.ZipLocation);

            //Borrar los archivos que ya no necesitamos
            if (Directory.Exists(GlobalVariables.Location))
                Directory.Delete(GlobalVariables.Location, true);

            if (Directory.Exists(GlobalVariables.SvgLocation))
                Directory.Delete(GlobalVariables.SvgLocation, true);

            //Devolver el zip
            return File(bytes, "application/octent-stream", "ModifiedSVG.zip");
        }
    }
}